// BNOM_ACT6_PARTE1
// PARTE 1 DE LA ACTIVIDAD 6
// BIANCA NOELIA OROZCO MORAN 368404
// 28 DE SEPTIEMBRE 2022

#include <stdio.h>
#include <stdlib.h>
#define N 10
//*** PROTOTIPOS DE FUNCIONES  ******
int validNum();
int msges();
int msges_ciclos();
void menu();

void Fibonacci_Ciclos (void);
void Fibonacci_For (void);
void Fibonacci_While (void);
void Fibonacci_DoWhile (void);

void Factorial_Ciclos (void);
void Factorial_For (void);
void Factorial_While (void);
void Factorial_DoWhile (void);

void Digitos_Ciclos (void);
void Digitos_For (void);
void Digitos_While (void);
void Digitos_DoWhile (void);

//****  VALIDACION DE NUMEROS  *********
int validNum ()
{
	int num;
	char xnum[30];
	fflush(stdin);
	gets(xnum);
	num = atoi(xnum);
	return num;
}
//****  main principal  *********
int main()
{
   menu();

	return 0;
}
//  *** DESARROLLO DE LAS FUNCIONES  ******
//********************* MENSAJES DEL MENU PRINCIPAL
int msges()
{ int op;
  system ("CLS");
  printf ("   M  E   N   U \n");
  printf("1.- FIBONACCI \n");
  printf("2.- FACTORIAL \n");
  printf("3.- DIGITOS \n");
  printf("0.- SALIR  \n");
  printf("ESCOGE UNA OPCION: ");
  op = validNum();
  return op;
}
//*********************  MENSAJES MENU DE CICLOS
int msges_ciclos()
{ int op_ciclos;
  system ("CLS");
  printf ("   C I C  L O S \n");
  printf("1.- FOR \n");
  printf("2.- WHILE \n");
  printf("3.- DO \n");
  printf("0.- SALIR  \n");
  printf("ESCOGE UNA OPCION: ");
  op_ciclos = validNum();
  return op_ciclos;
}
//****************                                                                               MENU PRINCIPAL
void menu()
{
  int op;
  do{
      op=msges();
      switch (op)
      {
        case 1:
              Fibonacci_Ciclos();
              break;
        case 2:
              Factorial_Ciclos();
              break;
        case 3:
              Digitos_Ciclos();
              break;

      }

    }while (op != 0);


}

//****************                                                                               MENU CILOS FIBONACCI
void Fibonacci_Ciclos()
{
  int op;
  do{
      op=msges_ciclos();
      switch (op)
      {
        case 1:
              Fibonacci_For();
              break;
        case 2:
              Fibonacci_While();
              break;
        case 3:
              Fibonacci_DoWhile();
              break;

      }

    }while (op != 0);


}

//****************                                                                               MENU CICLOS FACTORIAL
void Factorial_Ciclos()
{
  int op;
  do{
      op=msges_ciclos();
      switch (op)
      {
        case 1:
              Factorial_For();
              break;
        case 2:
              Factorial_While();
              break;
        case 3:
              Factorial_DoWhile();
              break;

      }

    }while (op != 0);


}

//****************                                                                               MENU CICLOS DEIGITOS
void Digitos_Ciclos()
{
  int op;
  do{
      op=msges_ciclos();
      switch (op)
      {
        case 1:
              Digitos_For();
              break;
        case 2:
              Digitos_While();
              break;
        case 3:
              Digitos_DoWhile();
              break;

      }

    }while (op != 0);


}

//*********************                                                                              FIBO FOR
void Fibonacci_For (void)
{
    //  VARIALES LOCALES
    int x = -1, y = 1, z = 0, i, n;
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FIBONACCI FOR\n"); 
    printf("VECES EN LAS QUE SE VA A REALIZAR EL CODIGO: ");
    n = validNum();
    
    for(i = 0;i < n;i++)
       {
       		printf("%d, ",z);
			x = y;
       		y = z;
       		z = x + y;
	   }
	printf("\n");
    system ("PAUSE");
}

//*********************                                                                               FIBO WHILE
void Fibonacci_While (void)
{
    //  VARIALES LOCALES
    int x = -1, y = 1, z = 0, i, n;
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FIBONACCI WHILE \n"); 
    printf("VECES EN LAS QUE SE VA A REALIZAR EL CODIGO: ");
    n = validNum();
    
    i=0;
    while (i < n)
          {
        		printf("%d, ",z);
				x = y;
       			y = z;
       			z = x + y;
       			i += 1;
		  }
	printf("\n");
    system ("PAUSE");
}

//*********************                                                                               FIBO DO
void Fibonacci_DoWhile (void)
{
    //  VARIALES LOCALES
	int x = -1, y = 1, z = 0, i, n; 
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FIBONACCI DO WHILE\n"); 
    printf("VECES EN LAS QUE SE VA A REALIZAR EL CODIGO: ");
    n = validNum();
    
    i = 0;
    do
      {
				printf("%d, ",z);
				x = y;
       			y = z;
       			z = x + y;
       			i += 1;
       			
	  } while (i < n);
	printf("\n");
	  
    system ("PAUSE");
}

//*************************                                                                               FACT FOR
void Factorial_For (void)
{

    //  VARIALES LOCALES 
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FACTORIAL FOR\n"); 
    system ("PAUSE");
}

//*************************                                                                               FACT WHILE
void Factorial_While (void)
{

    //  VARIALES LOCALES 

    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FACTORIAL WHILE\n"); 
    
    system ("PAUSE");
}

//*************************                                                                               FACT DO
void Factorial_DoWhile (void)
{

    //  VARIALES LOCALES 
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   FACTORIAL DO WHILE\n"); 
    system ("PAUSE");
}

//****************************                                                                               DIG FOR
void Digitos_For (void)
{
    //  VARIALES LOCALES 
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   DIGITOS FOR\n"); 
    system ("PAUSE");

}

//****************************                                                                               DIG WHILE
void Digitos_While (void)
{
    //  VARIALES LOCALES 
	int cont=0,n,num;
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   DIGITOS WHILE\n"); 
    printf("DAME EL NUMERO: ");
    n = validNum();
    num = n;
    
    while (n!=0)
          {
          		cont ++;
          		n /= 10;
		  }
	printf("\n %d TIENE %d DIGITOS.",num,cont);
    system ("PAUSE");

}

//****************************                                                                               DIG DO
void Digitos_DoWhile (void)
{
    //  VARIALES LOCALES 
    system ("CLS");
    //  AQUI DESARROLLO PROGRAMA
    printf("   DIGITOS DO WHILE\n"); 
    system ("PAUSE");

}
