#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>

#define ENTER 13
#define TAB 9
#define ARRIBA 72
#define ABAJO 80
#define DERECHA 77
#define IZQUIERDA 75

void LeerApellidoPaterno(char ap[]);
void LeerNombres(char c1[], char c2[]);
void LeerFecha(char Fc[]);
void ImprCurp(char c1[], char c2[], char ap[],char am[], char Fc[],int sexo, char EntFed[]);
void CURPS();

int LeerSexo();
int LeerEntFed(char EntFed[]);

int main()
{
	bool salir = false;
	char op;
	
	do
	{
		CURPS();
		system("pause");
		system("cls");	
		printf("�QUIERES CALCULAR OTRO CURP? (Y/N)\n");
		fflush(stdin);
		op = getch();
		printf("%c",op);
		if (op == 'N' || op == 'n')
		{
			salir = true;
		}
	}while (!salir);
	printf("GRACIAS POR USAR EL CODIGO :)");

	return 0;
}

//***********************************************************************************************
//Confirmar entrada de datos

//***********************************************************************************************
// CREADOR DE CURPS
void CURPS()
{
	char c1[20], c2[20], ap[20], am[20], Fc[9],EntFed[2];
	int sexo;
		//LeerNombres(c1,c2);
		LeerApellidoPaterno(ap);
		//LeerApellidoMaterno(am);
		//LeerFecha(Fc);
		//sexo = LeerSexo();
		//LeerEntFed(EntFed);
	
		ImprCurp(c1,c2,ap,am,Fc,sexo,EntFed);
}
//***********************************************************************************************
//Leer Nombres
void LeerNombres(char c1[], char c2[])
{
	char n1[20],n2[20],Esp[1], a[2];
	int car, i=0, DobEsp, EspI, j, Espp=0,k=0, carA;
	bool ValA=false;
	
	do{
		i=0;
		k=0;
		Espp=0;
		system ("CLS");
		printf("Ingresa Tus Nombres:");
		do{
			car=getch();
			
			if(car==8 && i!=0 && Espp==0 && k==0){
				i=i-1;
				system ("CLS");
				printf("Ingresa Tus Nombres:");
				for(j=0;j<=i-1 ;j++){
					
					printf("%c",n1[j]);
				}
			}
			if(car==8 && k!=0 && Espp==1){
				k=k-1;
				system ("CLS");
				printf("Ingresa Tus Nombres:");
				for(j=0;j<=i-1 ;j++){
					
					printf("%c",n1[j]);
				}
				for(j=0;j<=k-1 ;j++){
					
					printf("%c",n2[j]);
				}
				if(k==0){Espp=0;}
			
			}
			else{
				if(car >=97 && car <=122)
				{car = car-32;}
				if((car>=65 && car <=90) || car==32)
				{
					if(i==0 && car==' '){EspI=1;}
					if(car==' '){Espp=1;}
					else{EspI=0;}
					if(EspI==0 && Espp==0)
					{
						if(n1[i-1]==' ' && car==' '){DobEsp=1;}
						else {DobEsp=0;}
						if(DobEsp==0)
						{
							printf("%c",car);
							n1[i]=car;
							i++;
						}
					}
					if(Espp==1)
					{
						if(n1[k-1]==' ' && car==' '){DobEsp=1;}
						else {DobEsp=0;}
						if(DobEsp==0)
						{
							printf("%c",car);
							n2[k]=car;
							k++;
						}
					}
				}
			}
		}while(car!=ENTER && i!=20 && Espp!=2);
		n1[i]='\0';
		n2[k]='\0';
		fflush(stdin);
		if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
		printf("\nPrimer nombre: %s\n",n1);
		for(j=0;j<k;j++)
		{
			n2[j]=n2[j+1];
		}
		printf("Segundo nombre: %s\n",n2);
		strcpy(c1,n1);
		strcpy(c2,n2);
		printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}
//**********************************************************************************
//Leer apellido paterno
void LeerApellidoPaterno(char ap[])
{
	int car, i=0, DobEsp, EspI, j, Espp=0, a[2];
	char AP[20],Esp[1], carA;
	bool ValA=false;
	do{
		i=0;
		Espp=0;
		system ("CLS");
		printf("Ingresa Apellido Paterno:");
	
	do{
		Espp=0;
		car=getch();
		
		if(car==8 && i!=0){
			i=i-1;
			system ("CLS");
			printf("Ingresa Apellido Paterno:");
			for(j=0;j<=i-1 ;j++){
				
				printf("%c",AP[j]);
			}
		}
		else{
			if(car >=97 && car <=122)
			{car = car-32;}
			if((car>=65 && car <=90 ) || car==32)
			{
				if(i==0 && car==' '){EspI=1;}
				if(car==' '){Espp=1;}
				else{EspI=0;}
				if(EspI==0 && Espp==0)
				{
					if(AP[i-1]==' ' && car==' '){DobEsp=1;}
					else {DobEsp=0;}
					if(DobEsp==0)
					{
						printf("%c",car);
						AP[i]=car;
						i++;
					}
				}
			}
			if(car==164 || car == 165)
			{
				printf("%c",165);
				AP[i]=165;
				i++;
			}
		}
	}while(car!=ENTER);
	AP[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\nApellido paterno: %s\n",AP);
	strcpy(ap,AP);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer apellido materno
void LeerApellidoMaterno(char am[])
{
	int car, i=0, DobEsp, EspI, j, Espp=0, a[2];
	char AM[20],Esp[1], carA;
	bool ValA=false;
	do{
		i=0;
		Espp=0;
		system ("CLS");
		printf("Ingresa Apellido Materno:");
	
	do{
		Espp=0;
		car=getch();
		
		if(car==8 && i!=0){
			i=i-1;
			system ("CLS");
			printf("Ingresa Apellido Materno:");
			for(j=0;j<=i-1 ;j++){
				
				printf("%c",AM[j]);
			}
		}
		else{
			if(car >=97 && car <=122)
			{car = car-32;}
			if((car>=65 && car <=90 ) || car==32)
			{
				if(i==0 && car==' '){EspI=1;}
				if(car==' '){Espp=1;}
				else{EspI=0;}
				if(EspI==0 && Espp==0)
				{
					if(AM[i-1]==' ' && car==' '){DobEsp=1;}
					else {DobEsp=0;}
					if(DobEsp==0)
					{
						printf("%c",car);
						AM[i]=car;
						i++;
					}
				}
			}
			if(car==164 || car == 165)
			{
				printf("%c",165);
				AM[i]=165;
				i++;
			}
		}
	}while(car!=ENTER);
	AM[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\nApellido materno: %s\n",AM);
	strcpy(am,AM);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer fecha
void LeerFecha(char Fc[])
{
	
	bool Val = true, ValA=false;
	int car, i=0, DobEsp, EspI, j, a[2];
	char D[3],M[3],Y[20],Esp[1],c2[20], carA;
	do{
		i=0;
		system ("CLS");
		printf("Ingresa Apellido Materno:");
	
	do{
		if(Val==false){i=0;}
		system("CLS");
		printf("Ingresa tu Fecha de nacimiento: __/__/____");
		if(Val==false){printf("\nFecha invalida ");}
	do{
		car=getch();
		
		if(car>=48 && car<=57 || car==8){
		if(car==8 && i!=0){
			i=i-1;
				if(i==0){
						system("CLS");
						printf("Ingresa tu Fecha de nacimiento: __/__/____");
					}
				if(i!=0 && i<=2)
					{
						system("CLS");
						if(i-1==0){printf("Ingresa tu Fecha de nacimiento: %c_/__/____",D[0]);}
						if(i-1==1){printf("Ingresa tu Fecha de nacimiento: %c%c/__/____",D[0],D[1]);}
						
					}
					if(i>=3 && i<=4)
					{
						system("CLS");
						if(i-1==2){printf("Ingresa tu Fecha de nacimiento: %c%c/%c_/____",D[0],D[1],M[0]);}
						if(i-1==3){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/____",D[0],D[1],M[0],M[1]);}
						
					}
					
					if(i>=5 && i<=9)
					{
						system("CLS");
						if(i-1==4){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c___",D[0],D[1],M[0],M[1],Y[0]);}
						if(i-1==5){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c__",D[0],D[1],M[0],M[1],Y[0],Y[1]);}
						if(i-1==6){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c_",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2]);}
						if(i-1==7){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c%c",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2],Y[3]);}
						
					}
					
		}
		else{
				if(i==0){
						system("CLS");
						printf("Ingresa tu Fecha de nacimiento: __/__/____");
					}
				if(car==' '){EspI=1;}
				else{EspI=0;}
				if(EspI==0 && car!=8)
				{
					if(i<=1)
					{
						system("CLS");
						D[i]=car;
						if(i==0){printf("Ingresa tu Fecha de nacimiento: %c_/__/____",D[0]);}
						if(i==1){printf("Ingresa tu Fecha de nacimiento: %c%c/__/____",D[0],D[1]);}
					}
					if(i>=2 && i<=3)
					{
						system("CLS");
						M[i-2]=car;
						if(i==2){printf("Ingresa tu Fecha de nacimiento: %c%c/%c_/____",D[0],D[1],M[0]);}
						if(i==3){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/____",D[0],D[1],M[0],M[1]);}
						
					}
					
					if(i>=4 && i<=8)
					{
						system("CLS");
						Y[i-4]=car;
						if(i==4){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c___",D[0],D[1],M[0],M[1],Y[0]);}
						if(i==5){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c__",D[0],D[1],M[0],M[1],Y[0],Y[1]);}
						if(i==6){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c_",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2]);}
						if(i==7){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c%c",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2],Y[3]);}
						
					}
					c2[i]=car;
					i++;
				}
			}
	}

	}while( i!=8 );
	int Dia = (int) strtol(D, NULL, 10);
	int Mes = (int) strtol(M, NULL, 10);
	int Year = (int) strtol(Y, NULL, 10);
	if (Year>=1900 && Year<=2021){
		if(Mes==1 || Mes==3 || Mes==5 || Mes==7 || Mes==8 || Mes==10 || Mes==12){
			if(Dia>=1 && Dia<=31){Val=true;}
			else{Val=false;}
		}
		
		if(Mes==4 || Mes==6 || Mes==9 || Mes==11){
			if(Dia>=1 && Dia<=30){Val=true;}
			else{Val=false;}
		}
		
		if(Mes==2){
			if ( Year % 4 == 0 && Year % 100 != 0 || Year % 400 == 0){
			if(Dia>=1 && Dia<=29){Val=true;}
			else{Val=false;}
			}
			else{if(Dia>=1 && Dia<=28){Val=true;} else{Val=false;}}
		}
		
	}
	else{
		Val=false;
	}
	printf("\n%d/%d/%d\n",Dia,Mes,Year);
}while(Val!=true);
	
	c2[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\n%c%c/%c%c/%c%c%c%c\n",c2[0],c2[1],c2[2],c2[3],c2[4],c2[5],c2[6],c2[7]);
	strcpy(Fc,c2);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer sexo
int LeerSexo()
{
    int car, i=0, DobEsp, EspI, j, Espp=0, a[2];
	char Sexo[5],Esp[1], carA;
	int ValA=false, ValB=true;
	Sexo[0]=a;
	do{
		i=0;
		system ("CLS");
		printf("Selecciona tu Sexo:(Utilizando tabulador)  \n>Hombre		 Mujer");
	
	do{
		
		car=getch();
		
		
			if(car == TAB || i==0)
			{
			if(ValB==false)
			{
				system ("CLS");
				printf("Selecciona tu Sexo:(Utilizando tabulador)  \n Hombre		>Mujer");
				strcpy(Sexo, "Mujer");
				ValB=true;
			}
			
			else{
				system ("CLS");
				printf("Selecciona tu Sexo:(Utilizando tabulador) \n>Hombre		 Mujer");
				strcpy(Sexo, "Hombre");
				ValB=false;
			}
			
			}
			
		i++;
		
	}while(car!=ENTER);
	printf("\nSeleccionaste el genero: %s\n",Sexo);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
			}while(ValA==false);
	}while(a[0]!='Y');
	
	return ValB;
}

//**********************************************************************************
//Leer E.F.
int LeerEntFed(char EntFed[])
{
	char sig[][33] = {"AS","BC","BS","CC","CL","CM","CS","CH","DF","DG","GT","GR","HG","JC","MC","MN","MS","NT","NL","OC","PL","QT","QR","SP","SL","SR","TC","TS","TL","VZ","YN","ZS","NE"},a[2],carA,car,cad[][33] = {"AGUASCALIENTES","BAJA CALIFORNIA","BAJA CALIFORNIA SUR","CAMPECHE","COAHUILA","COLIMA","CHIAPAS","CHIHUAHUA","DISTRITO FEDERAL","DURANGO","GUANAJUATO","GUERRERO","HIDALGO","JALISCO","MEXICO","MICHOACAN","MORELOS","NAYARIT","NUEVO LEON","OAXACA","PUEBLA","QUERETARO","QUINTANA ROO","SAN LUIS POTOSI","SINALOA","SONORA","TABASCO","TAMAULIPAS","TLAXCALA","VERACRUZ","YUCATAN","ZACATECAS","NACIDO EN EL EXTRANJERO"};
	int i,ValA=false;
	do
	{
		system("cls");
		printf("Selecciona tu estado de nacimiento: %s \n", cad[0]);
		printf("Utiliza las flechas de tu teclado para seleccionar el estado.\n");
		i=0;
		do
		{
			car = getch();
			//printf("%d",car);
			
			if (car == DERECHA || car == ABAJO)
			{
				if (i == 32)
				{
					i = -1;
				}
				i++;
			}
			else
			{
				if (car == ARRIBA || car == IZQUIERDA)
				{
					if (i == 0)
					{
						i = 33;
					}
					i--;
				}
			}
			system("cls");
			printf("Selecciona tu estado de nacimiento: %s \n", cad[i]);
			printf("Utiliza las flechas de tu teclado para seleccionar el estado.\n");
		} while (car != ENTER);
		
		printf("\nSeleccionaste esta entidad federativa: %s\n",cad[i]);
		printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
			}while(ValA==false);
	} while(a[0]!='Y');
	strcpy(EntFed,sig[i]);
}

//**********************************************************************************
//Imprime el curp
void ImprCurp(char c1[], char c2[], char ap[],char am[], char Fc[],int sexo, char EntFed[])
{
	char curp[16] = "";
	int i,sal=false;
	curp[0] = ap[0];
	i=1;
	do
	{
		if(ap[i]=='A' || ap[i]=='E' || ap[i]=='I' || ap[i]=='O'|| ap[i]=='U') 
		{
			curp[1]=ap[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	if(strcmp(am,"")==0) // SI NO HAY NADA EN EL SEGUNDO APELLIDO, PONER UNA X
	{
		curp[2]='X';
	}
	else
	{
		curp[2] = am[0];
	}
	if(strcmp(c1,"JOSE")==0 && strcmp(c2,"")!=0) // SI EL NOMBRE ES COMPUESTO, Y EL PRIMERO ES JOSE
	{
		strcpy(c1,c2);
	}
	
	if(strcmp(c1,"MARIA")==0 && strcmp(c2,"")!=0) // SI EL NOMBRE ES COMPUESTO, Y EL PRIMERO ES MARIA
	{
		strcpy(c1,c2);
	}
	
	curp [3] = c1[0];
	curp [4] = Fc[6];
	curp [5] = Fc[7];
	curp [6] = 	Fc[2];
	curp [7] = Fc[3];
	curp [8] = Fc [0];
	curp [9] = Fc[1];
	curp [10] = (sexo==true)?'M':'H';
	curp [11] = EntFed[0];
	curp [12] = EntFed[1];
	//curp[13] = '\0';
	fflush(stdin);
	printf("EL CURP ES: ");
	
	
	sal = false;i=1;
	do
	{
		if(ap[i]=='A' || ap[i]=='E' || ap[i]=='I' || ap[i]=='O'|| ap[i]=='U') 
		{
		}
		else
		{
			curp[13]=ap[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	
	if (strcmp(am,"")!=0)
	{
			sal = false;i=1;
		do
		{
			if(am[i]=='A' || am[i]=='E' || am[i]=='I' || am[i]=='O'|| am[i]=='U') 
			{
			}
			else
			{
				curp[14]=am[i];
				sal = true;
			}
		i++;
		}while(sal == false);
	}
	else
	{
		curp[14]='X';
		
	}
	
	sal = false;i=1;
	do
	{
		if(c1[i]=='A' || c1[i]=='E' || c1[i]=='I' || c1[i]=='O'|| c1[i]=='U') 
		{
		}
		else
		{
			curp[15]=c1[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	
	// PONE UNA X EN LUGAR DE LA/S �
	for(i=0;i<16;i++)
	{
		if (curp[i]==-92 || curp[i]==-91 || curp[i]=='�' || curp[i]=='�')
		{
			curp[i]='X';
		}
	}
	
	// CENSURA DE PALABRAS ALTISONANTES
	if(curp [0] == 'P' && curp[1]=='E' && curp[2]=='N' && curp [3]=='E')
	{
		curp[1]='X';
	}
	if(curp [0] == 'T' && curp[1]=='E' && curp[2]=='T' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='U' && curp[2]=='L' && curp [3]=='O')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='I' && curp[2]=='J' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='U' && curp[2]=='T' && curp [3]=='O' && curp[3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='U' && curp[2]=='C' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='I' && curp[1]=='O' && curp[2]=='P' && curp [3]=='I' && curp [3]=='O')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='A' && curp[2]=='C' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'F' && curp[1]=='U' && curp[2]=='C' && curp [3]=='K')
	{
		curp[1]='X';
	}
	if(curp [0] == 'A' && curp[1]=='N' && curp[2]=='O' && curp [3]=='S')
	{
		curp[1]='X';
	}
	if(curp [0] == 'F' && curp[1]=='A' && curp[2]=='L' && curp [3]=='O')
	{
		curp[1]='X';
	}
	// IMPRIME EL CURP LETRA POR LETRA
	printf("\n");
	for(i=0;i<16;i++)
	{
		printf("%c",curp[i]);
	}
}
