// BNOM_ACT1_03
// PROGRAMA QUE PIDA UN NUMERO ENTRE 1 Y 10. DESPLEGAR EL FACRTORIAL DEL NUMERO DADO
// Bianca Noelia Orozco Mor�n ; 368404
// 12 DE AGOSTO DEL 2022

#include <stdio.h>
#include <stdlib.h>
#define p printf
#define s scanf

int main(){
	int j,num,fac=1;
	
	p("Dame un n%cmero entre 1 & 10:\n",163);
	s("%d",&num);
	system("cls");
	
	if(num>10){
		p("Este numero no esta dentro del rango");
	}
	else{
		for(j=num;j>1;j--){
		fac=fac*j;
	}
	
	p("%d! = %d",num,fac);
	}
	
	
	
	return 0;
}
