// BNOM_ACT1_04
// PROGRAMA  QUE PIDA UN NUMERO ENTRE 1 Y 10, DESPLEGAR LA TABLA DE MULTIPLICAR DE ESE NUMERO
// Bianca Noelia Orozco Mor�n ; 368404
// 12 DE AGOSTO DEL 2022

#include <stdio.h>
#include <stdlib.h>
#define p printf
#define s scanf

int main(){
	int num, i, mul;
	p("Dame un numero entre 1 y 10: ");
	s("%d",&num);
	system("cls");
	
	if(num>10){
		p("Este numero no esta dentro del rango");
	}
	else{
		for(i=1;i<=10;i++){
	 mul=num*i;
	 
	 p("%d x %d = %d\n",num,i,mul);
	}
	}
	
	return 0;
}
