// BNOM_ACT1_02
// PROGRAMA QUE LEA 3 NUMEROS, DESPLIEGA LOS 3 NUMEROS EN ORDEN ASCENDENTE
// Bianca Noelia Orozco Mor�n ; 368404
// 12 DE AGOSTO DEL 2022

#include <stdio.h>
#include <stdlib.h>
#define p printf
#define s scanf

int main(){
	int num1,num2,num3;
	
	p("Dame 3 numeros:\n");
	s("%d",&num1);
	s("%d",&num2);
	s("%d",&num3);
	system("cls");
	
	if(num1<num2){
		if(num1<num3){
			if(num2<num3){
				p("%d;%d;%d",num1,num2,num3);
			}
			else{
				p("%d;%d;%d",num1,num3,num2);
			}
		}
		else{
			p("%d;%d;%d",num3,num1,num2);
		}
	}
	else{
		if(num3<num1){
			if(num3<num2){
				p("%d;%d;%d",num3,num2,num1);
			}else{
				p("%d;%d;%d",num2,num3,num1);
			}
		}
		else{
			p("%d;%d;%d",num2,num1,num3);
		}
	}

	return 0;
}
