// BNOM_ACT06_02
// FACTORIAL_FOR
// Bianca Noelia Orozco Mor�n 368404
// 23 DE SEPTIEMBRE 2022


// NO TERMINADO********************//
#include <stdio.h>

int main ()
{
	int num, i, fact=1,n;
	
	printf("NUMERO DE LA FACTORIAL: ");
	scanf("%d",&num);
	n = num;
	for(i=1 ; i<= num ; i++)
	   {
			fact = fact * i;
			printf("%d * %d = %d \n",n++, i, fact);
	   }
	   
	printf("FACTORIAL DE %d = %d",num,fact);

}
