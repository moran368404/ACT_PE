// BNOM_ACT06_03
// DIGITOS_FOR
// Bianca Noelia Orozco Mor�n 368404
// 23 DE SEPTIEMBRE 2022

#include <stdio.h>
#include <string.h>

int main ()
{
	int dig, num[10];
	
	printf("DIME UN NUMERO: ");
	gets(num);
	
	dig = strlen(num);
	printf("%d",dig);
	
	
}
