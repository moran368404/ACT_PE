// BNOM_ACT06_01
// FIBONACCI_FOR
// Bianca Noelia Orozco Mor�n 368404
// 23 DE SEPTIEMBRE 2022

#include <stdio.h>
void fibo_for(int rep);
void fibo_while();
void fibo_dowhile();

int main ()
{
	int num,op,x;
	
	printf("DIME LAS VECES QUE QUIERES QUE SE REALICE EL PROGRAMA DE FIBONACCI: ");
	scanf("%d",&num);
	
	printf("1.- FOR\n");
	printf("2.- WHILE\n");
	printf("3.- DO WHILE\n");
	printf("ELIGE UNA OPCION: ");
	scanf("%d",&op);
	
	switch (op)
	       {
	       		case 1:
	       			fibo_for(num);
	       		break;
	       		
	       		case 2:
	       			fibo_while();
	       		break;
	       		
	       		case 3:
	       			fibo_dowhile();
	       		break;
		   }
		   
	
	
	
}

void fibo_for(int rep)
{
	int x = 0,y = 1,z,i;
	printf("Hola soy fibo for.\n");
	for (i=rep;i<rep;i++)
	    {
	    	printf("%d, ",z);
	    	x = y;
	    	y = z;
	    	z = x + y;
		}
}
void fibo_while()
{
	printf("hola soy fibo while.");
}
void fibo_dowhile()
{
	printf("Hola soy fibo dowhile.");
}
