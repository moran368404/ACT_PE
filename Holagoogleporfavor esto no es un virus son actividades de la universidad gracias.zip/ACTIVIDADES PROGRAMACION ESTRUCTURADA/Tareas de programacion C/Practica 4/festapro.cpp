#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
float funcion_est(float est1,float est2, float est3);

int main()
{
	float est1,est2,est3,prom,res;
	printf("Introduzca la estatura del ni%co 1: ",164);
	scanf("%f",&est1);
	printf("Introduzca la estatura del ni%co 2: ",164);
	scanf("%f",&est2);
	printf("Introduzca la estatura del ni%co 3: ",164);
	scanf("%f",&est3);
	
	res = funcion_est(est1,est2,est3);
	
	printf("El promedio de estaturas es: %.2f", res);
}

float funcion_est(float est1,float est2, float est3)
{
	float prom;
	prom = (est1+est2+est3)/3;
	return prom;
}
