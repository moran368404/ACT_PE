#include <stdio.h>
#include <conio.h>
#include <math.h>

// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
float funcion_hipo(float a,float b);

int main()
{
	float a,b,c,res;
	printf("Introduzca el valor de el cateto a: ");
	scanf ("%f",&a);
	printf("Introduzca el valor de el cateto b: ");
	scanf("%f",&b);
	
	res = funcion_hipo(a,b);
	
	printf("El valor de la hipotenusa es: %.2f",res);
}

float funcion_hipo(float a,float b)
{
	float c;
	c=sqrt(pow(a,2)+pow(b,2));
	return c;
}
