#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
float volcaj(float x,float y,float z);

int main()
{
	float x,y,z,res,vol;
	printf("Introduzca las medidas de la caja:\n");
	scanf("%f",&x);
	scanf("%f",&y);
	scanf("%f",&z);
	
	res = volcaj(x,y,z);
	printf("El volumen de la caja es: %f",res);
}

float volcaj(float x,float y,float z)
{
	float vol;
	vol=x*y*z;
	return vol;
}
