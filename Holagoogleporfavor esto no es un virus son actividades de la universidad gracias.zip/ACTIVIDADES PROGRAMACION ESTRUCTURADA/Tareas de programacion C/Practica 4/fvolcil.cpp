#include <stdio.h>
#include <conio.h>
#include <math.h>
#define pi 3.1416
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
float funcili(float radio, float alt);

int main ()
{
	float radio, alt, vol,res;
	printf("Introduzca el radio y la altura del cilindro: ");
	scanf("%f",&radio);
	scanf("%f",&alt);
	
	res=funcili(radio,alt);
	
	printf("El volumen del cilindro es: %f",res);
}

float funcili(float radio, float alt)
{
	float vol;
	vol=(pi*pow(radio,2))*alt;
	return vol;
}
