#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
float funcion_1(float x,float z, float y);

int main()
{
	float x,z,y,res;	
	printf("Dame 3 n%cmeros: ",163);
	scanf("%f",&x);
	scanf("%f",&y);
	scanf("%f",&z);
	
	res= funcion_1(x,y,z);
	
	printf ("%.2f", res);
	getch();
	return 0;
}

float funcion_1(float x,float z, float y)
{
	float menor;
	if (x>y)
	{
		menor=y;
	}
	if(y>z)
	{
		menor=z;
	}
	if(z>x)
	{
		menor=x;
	}
	return menor;
}
