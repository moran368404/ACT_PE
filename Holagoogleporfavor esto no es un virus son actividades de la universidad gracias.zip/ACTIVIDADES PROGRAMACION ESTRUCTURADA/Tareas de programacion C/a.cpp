#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdiolib.h>
#include <math.h>
//#include <ctype.h>

#define pi 3.1416
#define J 5
#define E 40

float area(float r, float h);
void llenar(float A[J][J],float B[J][J], int col, int ren);
void matriz(float A[J][J],float B[J][J],float C[J][J], int col, int ren);
void despeglar(float A[J][J],float B[J][J],float C[J][J], int col, int ren);
void llenar2(float A[E]);
float fibo(float A[E], int n);

int main(){
	int col,ren,i,j,n;
	float x1[J][J], x2[J][J], x3[J][J], F[E], A[E], r,h;
	char op;
	
	
	
	while (op !== 'e' or 'E'){
		printf ("Menu de examen\n");
		printf ("a) area del cilindro\n");
		printf ("b) sumar matrices\n");
		printf ("c) Desplegar promedio de...\n");
		printf ("d) Fibonacci\n");
		printf ("e) salir\n");
		scanf("%s",&op);
		
		switch (op){
			case ('a' or 'A'){
				system("cls");
				
				break;
			}
			case ('b' or 'B'){
				system("cls");
				break;
			}
			case ('c' or 'C'){
				system("cls");
				break;
			}
			case ('d' or 'D'){
				system("cls");
				break;
			}
			case ('e' or 'E'){
				system("cls");
				break;
			}
		}
	}
	
}
float area(float r, float h){
	int 
}

void llenar(float A[J][J],float B[J][J], int col, int ren)

void matriz(float A[J][J],float B[J][J],float C[J][J], int col, int ren)

void despeglar(float A[J][J],float B[J][J],float C[J][J], int col, int ren)

void llenar2(float A[E])

float fibo(float A[E], int n)



