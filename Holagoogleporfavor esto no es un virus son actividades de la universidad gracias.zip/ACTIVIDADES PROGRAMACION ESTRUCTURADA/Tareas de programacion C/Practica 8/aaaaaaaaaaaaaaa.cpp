#include <stdio.h>
#include <conio.h>
#include <math.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica N-R  //
//*********************************************//

float fxi(float x);
float fpxi(float x);
float x1(float x, float fxi, float fpxi);
float error(float act, float ant);
void desplegar(int n,float xi, float fxi, float fpxi, float x1, float erp);

int main (){
	float yi,erp,fyi,fpyi,y1,err;
	int i;
	
	printf("f(x) = (x^2)-9\n");
	printf("Valor inicial: ");
	scanf("%f",&yi);
	printf("\nError porcentual: %c",37);
	scanf("%f",&erp);
	
	for(i=0;erp>err;i++){
	    
	fyi=fxi(yi);
	fpyi=fpxi(yi);
	y1=x1(yi,fyi,fpyi);
	
	if(i==0){
	    err=100;
	}
    else{
        err=error(y1,yi);
    }
    
    desplegar(i,yi,fyi,fpyi,y1,err);
    
	}
	
	yi=y1;

}

float fxi(float x){
    float res;
    res=pow(x,2)-9;
    return res;
}

float fpxi(float x){
    float res;
    res= x;
    return res;
}

float c8(float x, float fxi, float fpxi){
    float res;
    res= x-(fxi/fpxi);
    return res;
}

float error(float act, float ant){
    float res;
    res= (abs((act-ant)/act))*100;
    return res;
}

void desplegar(int n,float xi, float fxi, float fpxi, float x1, float erp){
	printf("{ %1d.- | %11f | %11f | %11f | %11f | %11f }\n",n,xi,fxi,fpxi,c8,erp);
}
