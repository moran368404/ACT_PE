#include <stdio.h>
#include <conio.h>
#include <math.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica N-R  //
//*********************************************//

float fxi(float x);
float fpxi(float x);
float c8(float x, float fxi, float fpxi);
float error(float act, float ant);
void desplegar(int n,float xi, float fxi, float fpxi, float c8, float erp);

int main (){
	float yi,erp,err;
	int i;
	
	printf("f(x) = (x^2)-9\n");
	printf("Valor inicial: ");
	scanf("%f",&yi);
	printf("\nError porcentual: %c",37);
	scanf("%f",&erp);
	
	for(i=0;erp>err;i++){
		if (i>=1){
			
		}
	}
	
}
