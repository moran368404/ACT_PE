#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#define prinf p
#define scanf s

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 14.1 //
//*********************************************//

// Metodo de Jacobi

x(float a,float b,float c,float x,float y,float j);

int main {
float x1,x2,x3,a11,a12,a13,a21,a22,a23,a31,a32,a33,b1,b2,b3,erp,err;

p("*********************Metodo de Jacobi*********************");
p("Introduzca el valor de a11: ");
s("%f",&a11);
p("Introduzca el valor de a12: ");
s("%f",&a12);
p("Introduzca el valor de a13: ");
s("%f",&a13);

p("Introduzca el valor de a21: ");
s("%f",&a21);
p("Introduzca el valor de a22: ");
s("%f",&a22);
p("Introduzca el valor de a23: ");
s("%f",&a23);

p("Introduzca el valor de a31: ");
s("%f",&a31);
p("Introduzca el valor de a32: ");
s("%f",&a32);
p("Introduzca el valor de a33: ");
s("%f",&a33);

p("Introduzca el valor de b1: ");
s("%f",&b1);
p("Introduzca el valor de b2: ");
s("%f",&b2);
p("Introduzca el valor de b3: ");
s("%f",&b3);

p("%cQue porcentaje de error quieres?");
s("%f",&erp);

system("cls");

x1=0;
x2=0;
x3=0;

do{
	
	x1= x(a12,a13,a11,x2,x3,b1);
	x2= x(a21,a23,a22,x1,x3,b2);
	x3= x(a31,a32,a33,x1,x2,b3);
	
	
}while(err<erp)



}

x(float a,float b,float c,float x,float y,float j){
	
}
