#include <stdio.h>
#include <conio.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 7    //
//*********************************************//

float bisec(int xi,int xu);

int main()
{
	int a,b,c;
	printf ("Dime los valores de xi (superior): ");
	scanf("%d",&a);
	printf ("Dime los valores de xu (inferior): ");
	scanf("%d",&b);
	
	if (a < 0 && b < 0)
	{
		c=bisec(a,b);
		printf ("El resultado es: %d",c);
	}
	else
	{
		printf("Error, no es una raiz");
	}
	
	getch();
	return 0;
}

float bisec(int xi,int xu){
	int xr;
	xr=(xi+xu)/2;
	return xr;
}
