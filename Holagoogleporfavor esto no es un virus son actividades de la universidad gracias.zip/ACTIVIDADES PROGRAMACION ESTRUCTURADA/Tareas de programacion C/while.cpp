#include <stdio.h>
#include <conio.h>

int main()
{
	int i=1,n;
	printf("dame el valor de n");
	scanf("%d",&n);
	while (i<=n)
	{
		printf("\n%d",i);
		i=i+1;
	}
	getch();
	return 0;
}
