#include <stdio.h>
#include <conio.h>
#include <math.h>
#define pi 3.1416
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float J, A;
	printf("Dime el radio de el circulo ");
	scanf("%f",&J);
	A=pi*pow(J,2);
	printf("El resultado es: %.2f", A);
	getch();
	return 0;
}
