#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float J, A, S;
	printf("Dime la medida de la base ");
	scanf("%f",&J);
	printf("Dime la medida de la altura ");
	scanf("%f",&A);
	S=J*A;
	printf("El resultado es: %.2f", S);
	getch();
	return 0;
}
