#include <stdio.h>
#include <conio.h>
#include <math.h>
#define pi 3.1416
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float J,A,S;
	printf("Dime la medida de el radio ");
	scanf("%f",&J);
	printf("Dime la medida de la altura de la figura ");
	scanf("%f",&A);
	S=(2*pi*J*A)+(2*pi*pow(J,2));
	printf("El resultado es: %.2f",S);
	getch();
	return 0; 
}
