#include <stdio.h>
#include <conio.h>
#include <math.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float J,N;
	printf("Dime la medida de un lado ");
	scanf("%f",&J);
	N=6*pow(J,2),
	printf("El resultado es: %.2f", N);
	getch();
	return 0;
}
