#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int i,n,s=0,min=0,may=0,peso[40];
	float pesoprom;
	printf("Dame la cantidad de alumnos: ");
	scanf("%d",&n);
	for (i=0;i<n;i++)
	{
		printf ("Dame el peso del alumno: ");
		scanf("%d",&peso[i]);
		s=s+peso[i];
	}
	pesoprom=(float)s/n;
	printf("El peso promedio es de %.2f\n",pesoprom);
	for(i=0;i<n;i++)
	{
		if(peso[i]>pesoprom)
		may++;
		if(peso[i]<pesoprom)
		min++;
	}
	printf("Los alumnos con el peso mayor al promedio son: %d\n",may);
	printf("Los alumnos con el peso menor al promedio son: %d",min);
	getch();
	return 0;
}
