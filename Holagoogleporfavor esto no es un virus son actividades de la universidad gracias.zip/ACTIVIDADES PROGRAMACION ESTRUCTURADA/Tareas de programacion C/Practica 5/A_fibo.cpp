#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //

int main()
{
	int n,i,x=1,y=0,fibo[15];
	printf("Dame un n%cmero del 1-15: ",163);
	scanf("%d",&n);
	if (n<=15)
	{
		for(i=0;i<n;i++)
	{
		fibo[i]=x+y; x=y; y=fibo[i];
		printf("%d - ",fibo[i-1]);
	}
	}
	else
	{
		printf("Ese n%cmero no se encuentra dentro del rango",163);
	}
	getch ();
	return 0;
}
