#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int n,i,a[10],may,men,posmay,posmen;
	printf("Dame el tama%co del arreglo: ",164);
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Dame el n%cmero de el arreglo: ",163);
		scanf("%d",&a[i]);
		if(i==0)
		{
			may=a[i];
			men=a[i];
			posmay=0;
			posmen=0;
		}
		else
		{
			if(a[i]>may)
			{
				may=a[i];
				posmay=i;
			}
			if(a[i]<men)
			{
				men=a[i];
				posmen=i;
			}
		}
	}
	printf("\nEl n%cmero mayor esta en %d, y es %d\n",163,posmay,may);
	printf("El n%cmero menor esta en %d y es %d",163,posmen,men);
}
