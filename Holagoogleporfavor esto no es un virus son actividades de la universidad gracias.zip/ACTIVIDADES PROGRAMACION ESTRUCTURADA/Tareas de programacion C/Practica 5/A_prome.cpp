#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int n,m,i,j;
	float ppm,cali[5][5],acum,acum2,acum3,pg,cpp;
	printf("Dime la cantidad de materias: ");
	scanf("%d",&m);
	printf("Dime cuantos parciales son por materia: ");
	scanf("%d",&n);
	acum2=0;
	for (j=0;j<m;j++)
	{
		acum=0;
		for (i=0;i<n;i++)
		{
			printf("Dime la calificaci%cn de el parcial %d de la materia %d: ",162,i+1,j+1);
			scanf("%f",&cali[j][i]);
			acum+=cali[j][i];
		}
		ppm=acum/n;
		printf ("El promedio de la materia %d es: %.2f\n\n",j+1,ppm);
		acum2+=ppm;
	}
	
	for (i=0;i<n;i++)
	{
		acum3=0;
		for (j=0;j<m;j++)
		{
			acum3+=cali[j][i];
		}
		cpp=acum3/m;
		printf("El promedio del parcial %d es: %.2f\n",i+1,cpp);
	}
	pg=acum2/m;
	printf("El promedio general es: %.2f",pg);
	
	getch();
	return 0;
}
