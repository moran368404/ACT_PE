#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 5    //
//*********************************************//

void frase (char code[1000]);

int main ()
{
	char code[1000];
	printf("Escriba la frase que desea codificar\n");
	gets(code);
	system ("cls");
	printf("Frase sin codificar: %s",code);
	frase(code);
	
}

void frase (char code[1000])
{
	int i,j;
	i=strlen(code);
	for (j=0;j<i;j++)
	{
		if(code[j]==122){
			code[j]=96;	
		}	
		if(code[j]==' ')
			code[j]=code[j]-1;
		if(code[j]==90)
			code[j]=65;
		code[j]=code[j]+1;
	}
	printf("\nFrase codificada: %s",code);
}
