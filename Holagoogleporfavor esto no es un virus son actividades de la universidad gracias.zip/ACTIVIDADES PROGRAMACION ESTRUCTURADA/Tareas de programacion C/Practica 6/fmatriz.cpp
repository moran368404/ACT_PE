#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define J 5

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 5    //
//*********************************************//

void llenar(float mat[J][J],int ren, int col, char nom);
void desplegar(float mat[J][J],int ren, int col, char nom);
void suma(float x1[J][J], float x2[J][J], float x3[J][J],int ren, int col);
void rest(float x1[J][J], float x2[J][J], float x3[J][J],int ren, int col);
void mult(float x1[J][J], float x2[J][J], float x3[J][J],int ren, int col,int cX);

int main ()
{
    float X[J][J],Y[J][J],Z[J][J];
    int rX, cX, rY, cY;
    char op;
    
    while(op!='D')
    {
    printf("********************************Bienvenido al men%c de matrices********************************\n",163);
   	printf("Seleccione una de las opciones de lo que desee hacer:\n");
    printf("A) Suma de matrices\n");
    printf("B) Resta de matrices\n");
    printf("C) Multiplicaci%cn de matrices\n");
    printf("D) Salir\n");
    scanf("%s",&op);
    
	switch (op)
    {
    	case 'A':
    	{
   			system("cls");
			printf("Dime la cantidad de renglones de tu matriz X: ");
   			scanf("%d",&rX);
   			printf("Dime la cantidad de columnas de tu matriz X: ");
   			scanf("%d",&cX);
    		printf("Dime la cantidad de renglones de tu matriz Y: ");
    		scanf("%d",&rY);
    		printf("Dime la cantidad de columnas de tu matriz Y: ");
    		scanf("%d",&cY);
    		
			   if(rX==rY and cX==cY)
    		{
    			
        		llenar(X,rX,cX,'X');
        		llenar(Y,rY,cY,'Y');
				suma(X,Y,Z,rX,cY);
				desplegar(X,rX,cX,'X');
				desplegar(Y,rY,cY,'Y');
				desplegar(Z,rY,cY,'Z');
				system("pause");
				system("cls");
   			}
   			else
    		{
       		 	printf ("Las matrices no coinciden, el codigo se cerrar�\n");
    		}
    		break;
		}
		case 'B':
		{
			system("cls");
			printf("Dime la cantidad de renglones de tu matriz X: ");
   			scanf("%d",&rX);
   			printf("Dime la cantidad de columnas de tu matriz X: ");
   			scanf("%d",&cX);
    		printf("Dime la cantidad de renglones de tu matriz Y: ");
    		scanf("%d",&rY);
    		printf("Dime la cantidad de columnas de tu matriz Y: ");
    		scanf("%d",&cY);
    		
			   if(rX==rY and cX==cY)
    		{
    			
        		llenar(X,rX,cX,'X');
        		llenar(Y,rY,cY,'Y');
				rest(X,Y,Z,rX,cX); 
				desplegar(X,rX,cX,'X');
				desplegar(Y,rY,cY,'Y');
				desplegar(Z,rY,cY,'Z');
				system("pause");
				system("cls");
   			}
   			else
    		{
       		 	printf ("Las matrices no coinciden, el codigo se cerrar�\n");
    		}
    		break;
		}
		case 'C':
		{
			printf("Dime la cantidad de renglones de tu matriz X: ");
   			scanf("%d",&rX);
   			printf("Dime la cantidad de columnas de tu matriz X: ");
   			scanf("%d",&cX);
    		printf("Dime la cantidad de renglones de tu matriz Y: ");
    		scanf("%d",&rY);
    		printf("Dime la cantidad de columnas de tu matriz Y: ");
    		scanf("%d",&cY);
    		
			   if(rX==rY and cX==cY)
    		{
    			
        		llenar(X,rX,cX,'X');
        		llenar(Y,rY,cY,'Y');
				mult(X,Y,Z,rX,cY,cX);
				desplegar(X,rX,cX,'X');
				desplegar(Y,rY,cY,'Y');
				desplegar(Z,rY,cY,'Z');
				system("pause");
				system("cls");
   			}
   			else
    		{
       		 	printf ("Las matrices no coinciden, el codigo se cerrar�\n");
    		}
    		break;
		}
		case 'D':
		{
			printf("Muchas gracias por usar el codigo!!");
		}
	}
	}

    getch ();
    return 0;
}
    // Funcion para *llenar* las matrices
void llenar(float mat[J][J],int ren, int col, char nom)
{
     int i,j;
     printf("\n-------------> Llenado de la matriz %c <-------------\n",nom);
     for(i=0;i<ren;i++)
     {
      for(j=0;j<col;j++)
      {
       printf("%c[%d][%d]= ",nom,i,j);
       scanf("%f",&mat[i][j]);
      }
     }
}

     // Funcion para *desplegar* las matrices
void desplegar(float mat[J][J],int ren, int col, char nom)
{
     int i,j;
     printf("\n-------------> Elementos de la matriz %c <-------------",nom);
     for(i=0;i<ren;i++)
     {
     printf("\n[ ");
      for(j=0;j<col;j++)
      {
       printf("%.2f  ",mat[i][j]);
      }
     printf(" ]\n");
     }
}

     // Funcion para *sumar* las matrices
void suma(float x1[J][J],float x2[J][J],float x3[J][J],int ren, int col)
{
     int i,j;
     for(i=0;i<ren;i++)
     {
     	for(j=0;j<col;j++)
     	{
     		x3[i][j]=x1[i][j]+x2[i][j];
		}
	 }

}

     // Funcion para *restar* las matrices
void rest(float x1[J][J],float x2[J][J],float x3[J][J],int ren, int col)
{
     int i,j;
     for(i=0;i<ren;i++)
     {
     	for(j=0;j<col;j++)
     	{
     		x3[i][j]=x1[i][j]-x2[i][j];
		}
	 }
}

     // Funcion para *multiplicar* las matrices
void mult(float x1[J][J],float x2[J][J],float x3[J][J],int ren, int col,int cX)
{
     int i,j,s;
     float cont=0;
     for(i=0;i<ren;i++)
     {
     	for(j=0;j<col;j++)
     	{
     		x3[i][j]=0;
     		for(s=0;s<cX;s++)
     		{
     			x3[i][j]=(x3[i][j]+(x1[i][s]*x2[s][i]));
			}
		}
	 }
}
