#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <stdlib.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 5    //
//*********************************************//

float siono (char pali[100]);

int main()
{
	char pali[100];
	int r;
	printf("Dime una frase y te dir%c si es un pal%cndromo o no:\n",130,161);
	gets(pali);
	r=siono(pali);
	system("cls");
	
	if(r==1)
	{
		printf("La frase '%s' s%c es un pal%cndromo",pali,161,161);
	}
	else
	{
		printf("La frase '%s' no es un pal%cndromo",pali,161);
	}
}

float siono (char pali[100])
{
	char pali2[40];
	char j=' ';
	int n, i, x, a=0, p=0, e=0, Z=0;
	
	n=strlen(pali);
	for(i=0;i<=n;i++)
	{
		if (pali[i]==j)
		i++;
		pali2[e]=pali[i];
		e++;
	}
	for (x=n-1;x>=0;x--)
	x=0;
	n=strlen(pali2);
		for (x=n-1;x>=0;x--)
		{
			if(pali2[x]==pali2[a])
			p++;
			a++;
		}
		
		if(p==n)
		{
			pali[40] = 1;
		}
		else
			pali[40] = 0;
	return pali[40];
}
