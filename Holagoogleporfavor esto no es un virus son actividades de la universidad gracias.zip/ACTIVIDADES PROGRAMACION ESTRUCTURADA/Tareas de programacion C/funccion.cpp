#include <stdio.h>
#include <conio.h>

void mensaje(void); // prototipo de la funcion, si esta asi, indica que no va a recibir ni regresar ninguna info.

int main ()
{
	mensaje(); //llamado a la funcion
	getch();
	return 0;
}
//Cuerpo de la funcion
void mensaje(void)
{
	printf("Hola Mundo:)");
}
