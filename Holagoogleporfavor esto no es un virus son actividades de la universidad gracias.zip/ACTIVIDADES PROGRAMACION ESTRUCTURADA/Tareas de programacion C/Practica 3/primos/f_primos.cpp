#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int f,mul,div,i;
	printf("Quiero saber los numeros primos de el uno al: ");
	scanf ("%d",&f);
	
	if (f>=1)
	{
		printf ("1 - ");
	}
	
	for (i=1;i<=f;i++)
	{
		mul=1;
		div=0;
		while (mul<=i)
		{
			if(i%mul==0)
			{
				div=div+1;
			}
			mul=mul+1;
		}
		if(div==2)
		{
			printf("%d - ",i);
		}
	}
	getch();
	return 0;
}
