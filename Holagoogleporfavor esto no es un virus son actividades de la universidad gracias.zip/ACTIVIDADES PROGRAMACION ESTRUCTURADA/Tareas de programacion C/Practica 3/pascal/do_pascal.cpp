#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int n,i,j,nt;
	printf("Introduzca un numero ");
	scanf("%d", &n);
	i=0;
	do
	{
		nt=1;
		for (j=0;j<=i;j++)
		{
			printf("%d ",nt);
			nt = nt*(i-j)/(j+1);
		}
		printf("\n");
		i=i+1;
	}
	while (i<n);
	getch();
	return 0;
 }

