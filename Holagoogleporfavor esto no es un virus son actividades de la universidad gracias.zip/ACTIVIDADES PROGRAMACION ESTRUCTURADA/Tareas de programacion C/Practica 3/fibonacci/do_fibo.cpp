#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	int n,i,x=1,y=0,z=0;
	printf ("�Cuantos terminos va a tener su serie? ");
	scanf ("%i",&n);
	printf("0");
	i=0;
	do
	{
		z=x+y;
		x=y;
		y=z;
		printf(" %i",z);
		i=i+1;
	}
	while (i<=n-2);
	getch ();
	return 0;
}
