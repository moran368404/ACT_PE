#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <math.h>
#define pi 3.1416
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	int i;
	char op;
	float b,a,p,vc,r,v,ab;
	
	while(op!=3)
	{
		printf("Seleccione una opci%cn:\n",162);
		printf("a) Volumen de una caja\n");
		printf("b) Volumen de una esfera\n");
		printf("c) Volumen de un cilindro\n");
		printf("d) Volumen de una pir%cmide de 4 caras\n",160);
		printf("e) Salir\n");
		scanf("%s",&op);
	
		switch (op)
		{
			case 'a':
			case 'A':
				system("cls");
				printf("Usted ha seleccionado la opci%cn: Volumen de una caja",162);
				printf("\nIntroduzca el valor de la base: ");
				scanf("%f",&b);
				printf("Introduzca el valor de la altura: ");
				scanf("%f",&a);
				printf("Introduzca el valor de la profundidad: ");
				scanf("%f",&p);
				v = b*a*p;
				printf("El resultado es de %.2f unidades c%cbicas\n",v,163);
				break;
			case 'b':
			case 'B':
				system("cls");
				printf("Usted ha seleccionado la opci%cn: Volumen de una esfera",162);
				printf("\nIntroduzca el valor del radio de la esfera: ");
				scanf("%f",&r);
				v=(pi*pow(r,3)*4)/3;
				printf("El resultado es de %.2f unidades c%cbicas.\n",v,163);
				break;
			case 'c':
			case 'C':
				system("cls");
				printf("Usted ha seleccionado la opci%cn: Volumen de un cilindro",162);
				printf("\nIntroduzca el valor de el radio de la base: ");
				scanf("%f",&r);
				printf("Introduzca el valor de la altura: ");
				scanf("%f",&a);
				v=(pow(pi*r,3)*a);
				printf("El resultado es de %.2f unidades c%cbicas\n",v,163);
				break;
			case 'd':
			case 'D':
				system("cls");
				printf("Usted ha seleccionado la opci%cn: Volumen de una pir%cmide de 4 caras",162,160);
				printf("\nIntroduzca el valor del area de la base: ");
				scanf("%f",&ab);
				printf("Ingrese el valor de la altura de la piramide: ");
				scanf("%f",&a);	
				v=(ab*a)/3;
				printf("El resultado es de %.2f unidades cubicas.\n",v);
				break;
				
			case 'e':
			case 'E':
				printf("Usted ha seleccionado la opci%cn e",162);
				printf ("\nGracias por usar el c%cdigo, nos vemos",162);
				return 0;
				break;
			default:
				printf ("Esa opcion no esta dentro de el rango, intentelo de nuevo\n");
				break;
		}
	system("pause");
	system ("cls");
	}
	
	getch ();
	return 0;
}
