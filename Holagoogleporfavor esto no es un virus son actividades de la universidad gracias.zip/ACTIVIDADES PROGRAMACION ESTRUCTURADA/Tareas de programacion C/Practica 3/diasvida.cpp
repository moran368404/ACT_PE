#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int dn,mn,an,da,ma,aa,i,count=0,j;
	printf ("Dame tu fecha de nacimiento\n");
	printf ("D%ca: ",161);
	scanf ("%d",&dn);
	printf ("Mes: ");
	scanf ("%d",&mn);
	printf ("A%co: ",164);
	scanf ("%d",&an);
		if (dn>31 or mn>12)
		{
		printf("Esta fecha no es v%clida\n",160);
		return 0;
		}
	printf ("Dame la fecha actual\n");
	printf ("D%ca: ",161);
	scanf ("%d",&da);
	printf ("Mes: ");
	scanf ("%d",&ma);
	printf ("A%co: ",164);
	scanf ("%d",&aa);
		if (da>31 or ma>12)
		{
		printf("Esta fecha no es v%clida\n",160);
		return 0;
		}

	for (i=an;i<=aa-2;i++)
	{
		if (i%4==0 and i%100!=0 || i%400==0)
		{
			count=count+366;
		}
		else
		{
			count=count+365;
		}
	}
	
	for (i=mn+1;i<=12;i++)
	{
		switch (i)
		{
			case 1:
			case 3:
			case 5:
			case 7:
			case 8:
			case 10:
			case 12:
				count=count+31;
				break;
			case 4:
			case 6:
			case 9:
			case 11:
				count=count+30;
				break;
			case 2:
				if (an%4==0 and an%100!=0 || an%400==0)
				{
				count=count+29;
				}
				else
				{
				count=count+28;
				}	
				break;
		}
	}
	
	for (j=1;j<=ma-1;j++)
	{
		switch (j)
		{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			count=count+31;
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			count=count+30;
			break;
		case 2:
			if (an%4==0 and an%100!=0 || an%400==0)
			{
			count=count+29;
			}
			else
			{				
			count=count+28;
			}	
			break;
		}
	}
	
	switch (mn)
	{
		case 1:
		case 3:
		case 5:
		case 7:
		case 8:
		case 10:
		case 12:
			count=count+(31-dn);
			break;
		case 4:
		case 6:
		case 9:
		case 11:
			count=count+(30-dn);
			break;
		case 2:
			if (an%4==0 and an%100!=0 || an%400==0)
			{
			count=count+(29-dn);
			}
			else
			{
			count=count+(28-dn);
			}	
			break;
	}
	
	switch (ma)
	{
		default: count=count+da;
		break;
	}
	printf("Usted ha vivido %d d%cas",count,161);
	getch();
	return 0;
}
