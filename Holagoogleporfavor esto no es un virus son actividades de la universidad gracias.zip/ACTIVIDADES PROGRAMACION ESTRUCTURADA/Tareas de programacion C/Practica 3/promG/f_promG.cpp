#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	float cali, ac, promind, acca, promtot;
	int n,c,i;
	printf ("�Cuantos estudiantes son? ");
	scanf ("%d", &n);
	for (c=1;c<=n;c++)
	{
		printf ("C A L I F I C A C I O N E S  E S T U D I A N T E: %d\n",c);
		for (i=1;i<=4;i++)
		{
			printf("Introduzca la calificacion de el examen %d: ",i);
			scanf ("%f", &cali);
			
			acca= cali + acca;
		}	
		promind = acca/4;		
		printf("El promedio del ni�o '%d' es: %.2f\n",c,promind);
		ac = promind + ac;
		acca=0;
	}
	promtot = ac/n;
	printf ("El promedio general de el grupo es %f",promtot);
	
	getch ();
	return 0;
}
