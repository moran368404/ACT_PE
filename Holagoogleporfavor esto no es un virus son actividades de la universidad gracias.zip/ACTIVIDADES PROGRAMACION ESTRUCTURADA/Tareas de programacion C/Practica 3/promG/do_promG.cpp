#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	int est,i,n,acum, acca;
	float cali, promtot, ac, promind;
	printf ("�Cuantos estudiantes son? ");
	scanf ("%d",&est);
	i=0;
	do
	{
	i=i+1;
		printf("C A L I F I C A C I O N E S  E S T U D I A N T E: %d\n",i);
		n=0;
		do
		{
			n=n+1;
			printf ("�Cual es la calificacion de el examen %d? ",n);
			scanf ("%f",&cali);
			
			acca=cali+acca;
		}
		while (n<4);
		promind = acca/4;		
		printf("El promedio del ni�o '%d' es: %.2f\n",i,promind);
		ac = promind + ac;
		acca=0;
	}
		while (i<est);
		
		promtot = ac/est;
		printf ("El promedio general de el grupo es %.2f",promtot);
		getch();
		return 0;
}
