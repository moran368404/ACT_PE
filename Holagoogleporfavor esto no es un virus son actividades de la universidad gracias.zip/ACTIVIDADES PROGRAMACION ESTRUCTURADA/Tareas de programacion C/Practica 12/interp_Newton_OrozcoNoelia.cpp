#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>


//****************************************************//
//    <3 Hecho por: Bianca Noelia Orozco Mor�n <3     //
// Matr�cula: 368404  Grupo:24   Pr�ctica Int.Newton  //
//****************************************************//

float a1(float x0,float fx0,float x1,float fx1);
float a2(float x0,float fx0,float x1,float fx1,float x2,float fx2);
float a3(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3);
float a4(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x4,float fx4);

int main(){
	float b0,b1,b2,b3,b4,y0,fy0,y1,fy1,y2,fy2,y3,fy3,y4,fy4,y,aprox;
	int grad;
	
	do{
		system("cls");
		printf("Este c%cdigo resuelve hasta ecuaciones de 4to grado\n",162);
		printf("%cDe qu%c grado es la ecuaci%cn?\n",168,130,162);
		scanf("%d",&grad);
	
	switch(grad){
		case 1:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			b0=fy0;
			b1=a1(y0,fy0,y1,fy1);
			aprox=b0+(b1*(y-y0));
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
			
		case 2:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			b0=fy0;
			b1=a1(y0,fy0,y1,fy1);
			b2=a2(y0,fy0,y1,fy1,y2,fy2);
			aprox=b0+(b1*(y-y0))+(b2*(y-y0)*(y-y1));
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
		
		case 3:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("x3= ");
			scanf("%f",&y3);
			printf("fx3= ");
			scanf("%f",&fy3);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			b0=fy0;
			b1=a1(y0,fy0,y1,fy1);
			b2=a2(y0,fy0,y1,fy1,y2,fy2);
			b3=a3(y0,fy0,y1,fy1,y2,fy2,y3,fy3);
			aprox=b0+(b1*(y-y0))+(b2*(y-y0)*(y-y1))+(b3*(y-y1)*(y-y2)*(y-y3));
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
		
		case 4:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("x3= ");
			scanf("%f",&y3);
			printf("fx3= ");
			scanf("%f",&fy3);
			
			printf("x4= ");
			scanf("%f",&y4);
			printf("fx4= ");
			scanf("%f",&fy4);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			b0=fy0;
			b1=a1(y0,fy0,y1,fy1);
			b2=a2(y0,fy0,y1,fy1,y2,fy2);
			b3=a3(y0,fy0,y1,fy1,y2,fy2,y3,fy3);
			b4=a4(y0,fy0,y1,fy1,y2,fy2,y3,fy3,y4,fy4);
			aprox=b0+(b1*(y-y0))+(b2*(y-y0)*(y-y1))+(b3*(y-y1)*(y-y2)*(y-y3))+(b4*(y-y1)*(y-y2)*(y-y3)*(y-y4));
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
			
		case 5:
			printf("No esta disponible \n");
			system("pause");
			break;
	}
	}while(grad<6);
	
	
	getch();
	return 0;
}

float a1(float x0,float fx0,float x1,float fx1){
	float res;
	res=((fx1-fx0)/(x1-x0));
	return res;
}

float a2(float x0,float fx0,float x1,float fx1,float x2,float fx2){
	float res;
	res=((a1(x1,fx1,x2,fx2))-(a1(x0,fx0,x1,fx1)))/(x2-x0);
	return res;
}

float a3(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3){
	float res;
	res=((a2(x1,fx1,x2,fx2,x3,fx3))-(a2(x0,fx0,x1,fx1,x2,fx2)))/(x3-x0);
	return res;
}

float a4(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x4,float fx4){
	float res;
	res=((a3(x1,fx1,x2,fx2,x3,fx3,x4,fx4))-(a3(x0,fx0,x1,fx1,x2,fx2,x3,fx3)))/(x4-x0);
	return res;
}
