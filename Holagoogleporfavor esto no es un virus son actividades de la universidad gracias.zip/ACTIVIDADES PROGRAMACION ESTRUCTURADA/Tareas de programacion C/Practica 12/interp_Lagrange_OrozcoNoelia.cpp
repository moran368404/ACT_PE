#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>


//****************************************************//
//    <3 Hecho por: Bianca Noelia Orozco Mor�n <3     //
// Matr�cula: 368404  Grupo:24   Pr�ctica Int.Lgrnge  //
//****************************************************//

float a1(float x0,float fx0,float x1,float fx1,float x);
float a2(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x);
float a3(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x);
float a4(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x4,float fx4,float x);

int main(){
	float y0,fy0,y1,fy1,y2,fy2,y3,fy3,y4,fy4,y,aprox;
	int grad;
	
	do{
		system("cls");
		printf("Este c%cdigo solo resuelve hasta ecuaciones de 4to grado\n",162);
		printf("%cDe qu%c grado es la ecuaci%cn? (Escribir 6 si quiere salir)\n",168,130,162);
		scanf("%d",&grad);
		switch(grad){
		case 1:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			aprox=a1(y0,fy0,y1,fy1,y);
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
			
		case 2:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			aprox=a2(y0,fy0,y1,fy1,y2,fy2,y);
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
		
		case 3:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("x3= ");
			scanf("%f",&y3);
			printf("fx3= ");
			scanf("%f",&fy3);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			aprox=a3(y0,fy0,y1,fy1,y2,fy2,y3,fy3,y);
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
		
		case 4:
			printf("Ingrese los siguientes valores:\n");
			printf("x0= ");
			scanf("%f",&y0);
			printf("fx0= ");
			scanf("%f",&fy0);
			
			printf("x1= ");
			scanf("%f",&y1);
			printf("fx1= ");
			scanf("%f",&fy1);
			
			printf("x2= ");
			scanf("%f",&y2);
			printf("fx2= ");
			scanf("%f",&fy2);
			
			printf("x3= ");
			scanf("%f",&y3);
			printf("fx3= ");
			scanf("%f",&fy3);
			
			printf("x4= ");
			scanf("%f",&y4);
			printf("fx4= ");
			scanf("%f",&fy4);
			
			printf("Valor a aproximar:");
			scanf("%f",&y);
			
			aprox=a4(y0,fy0,y1,fy1,y2,fy2,y3,fy3,y4,fy4,y);
			printf("El resultado aproximado de 'x' es: %f \n",aprox);
			system("pause");
			break;
			
		case 5:
			printf("No esta disponible \n");
			system("pause");
			break;
	}

	
	}while(grad<6);
	
	
	
	getch();
	return 0;
}

float a1(float x0,float fx0,float x1,float fx1,float x){
	float res;
	res=(((x-x1)/(x0-x1))*fx0) + (((x-x0)/(x1-x0))*fx1);
	return res;
}

float a2(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x){
	float res;
	res=((((x-x1)*(x-x2))/((x0-x1)*(x0-x2)))*fx0) + ((((x-x0)*(x-x2))/((x1-x0)*(x1-x2)))*fx1) + ((((x-x0)*(x-x1))/((x2-x0)*(x2-x1)))*fx2);
	return res;
}

float a3(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x){
	float res;
	res=((((x-x1)*(x-x2)*(x-x3))/((x0-x1)*(x0-x2)*(x0-x3)))*fx0) + ((((x-x0)*(x-x2)*(x-x3))/((x1-x0)*(x1-x2)*(x1-x3)))*fx1) + ((((x-x0)*(x-x1)*(x-x3))/((x2-x0)*(x2-x1)*(x2-x3)))*fx2) + ((((x-x0)*(x-x1)*(x-x2))/((x3-x0)*(x3-x1)*(x3-x2)))*fx3);
	return res;
}

float a4(float x0,float fx0,float x1,float fx1,float x2,float fx2,float x3,float fx3,float x4,float fx4,float x){
	float res;
	res= ((((x-x1)*(x-x2)*(x-x3)*(x-x4))/((x0-x1)*(x0-x2)*(x0-x3)*(x0-x4)))*fx0) + ((((x-x0)*(x-x2)*(x-x3)*(x-x4))/((x1-x0)*(x1-x2)*(x1-x3)*(x1-x4)))*fx1) + ((((x-x0)*(x-x1)*(x-x3)*(x-x4))/((x2-x0)*(x2-x1)*(x2-x3)*(x2-x4)))*fx2) + ((((x-x0)*(x-x1)*(x-x2)*(x-x4))/((x3-x0)*(x3-x1)*(x3-x2)*(x3-x4)))*fx3) + ((((x-x0)*(x-x1)*(x-x2)*(x-x3))/((x4-x0)*(x4-x1)*(x4-x2)*(x4-x3)))*fx4);
	return res;
}
