#include <stdio.h>
#include <conio.h>

int main()
{
	int i,n;
	printf("Dame el valor de n ");
	scanf ("%d", &n);
	for (i=1;i<=n;i++)
	{
		printf("\n%d",i);
	}
	getch ();
	return 0;
}
// "for" no lleva punto y coma, los lleva dentro de el parentesis //
