#include <stdio.h>
#include <conio.h>

int main ()
{
	int i=1,n;
	printf("Dame el valor de n");
	scanf ("%d",&n);
	do
	{
		
	}
}
