#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	int i,n,s=0,min=0,may=0;
	float peso[30],pesprom;
	
	printf ("Dime la cantidad de alumnos: ");
	scanf ("%d",&n);
	for (i=0;i<n;i++)
	{
		printf("Dame el peso del alumno: ");
		scanf("%f",&peso[i]);
		s=s+peso[i];
	}
	
	pesprom=(float)s/n;
	printf ("El peso promedio es %f\n",pesprom);
	printf("El arreglo de los pesos es: ");
	for (i=0;i<n;i++)
	{
		printf("\n peso[%d] = %f\n",i,peso[i]);
		if(peso[i]>pesprom)
		may++;
		else
		min++;
	}
	printf("Los alumnos con el peso MENOR al promedio son: %d\n",min);
	printf("Los alumnos con el peso MAYOR al promedio son: %d\n",may);
	getch();
	return 0;
}
