#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// NO TERMINADOOO //
int main()
{
	int n,arre[10],i,may,min;
	may = min = arre[i];
	printf("Introduzca la cantidad de elementos que va a usar: ");
	scanf("%d",&n);
	
	for (i=0;i<n;i++)
	{
		printf("Escriba un n%cmero: ",163);
		scanf ("%d",&arre[i]);
		
		for (int i = 1; i < sizeof(arre) / sizeof(arre[i]); ++i)
	{
		if (arre[i] > may) may = arre[i];
		if (arre[i] < min) min = arre[i];
	}	
	
	}
	
	 printf ("El mayor es %d y el menor es %d.",may,min);
	for (i=0;i<n;i++)
	{
		printf("\n arre[%d] = %d\n",i,arre[i]);
	}
	getch ();
	return 0;
}
