#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 10   //
//*********************************************//

float fun(float x);
float fun1(float xi,float x0, float fxi, float fx0);
float error(float xa, float xi);
void desplegar (int n, float xi, float x0, float fxi, float fx0,float xa, float erp);

int main(){
	float yi,y0,ya,erp,fyi,fy0,err;
	int n=0;
	printf("Este c%cdigo usa la funci%cn ((x%c2)/4)-9\n",162,162,94);
	printf("xi = ");
	scanf("%f",&yi);
	printf("x(i-1) = ");
	scanf("%f",&y0);
	printf("erp = ");
	scanf("%f",&erp);
	system("cls");
	
	printf("{ n |    x i    |  x(i-1)   |   f(xi)   |  f(xi-1)  |    xi+1   |     erp   }\n");
	do{
	fyi=fun(yi);
	fy0=fun(y0);
	ya=fun1(yi,y0,fyi,fy0);
	err=error(ya,yi);
	desplegar(n,yi,y0,fyi,fy0,ya,err);
	y0=yi;
	yi=ya;
	n++;		
	} while (err>erp);
	
	printf("\nLa raiz es %.3f con un porcentaje de error de %.3f", ya,err);
}

float fun(float x){
	float res;
	res= (pow(x,2)/4)-9;
	return res;
}

float fun1(float xi,float x0, float fxi, float fx0){
	float res;
	res=xi-((fxi*(x0-xi))/(fx0-fxi));
	return res;
}

float error(float xa, float xi){
	float res;
	res= fabs((xa-xi)/xa)*100;
	return res;
}

void desplegar (int n, float xi, float x0, float fxi, float fx0, float xa, float erp){
	if (n==0){
		printf("{ %d | %9f | %9f | %9f | %9f | %9f |     --    }\n",n,xi,x0,fxi,fx0,xa);
	}
	else{
		printf("{ %d | %9f | %9f | %9f | %9f | %9f | %9f }\n",n,xi,x0,fxi,fx0,xa,erp);
	}
	
}
