#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float man, pres, prestot, desc;
	printf ("�Cuantos kilos de manzanas va a comprar?\n");
	scanf ("%f", &man);
	printf ("�Cuanto va a pagar?\n");
	scanf ("%f", &pres);	
	
	if (man > 0 and man <= 2)
	{
		desc = 0;
	}
	else
	{
		if (man <= 5)
		{
			desc = pres*.1;
		}
		else
		{
			if (man <= 10)
			{
				desc = pres*.15;
			}
			else
			{
				desc = pres*.20;
			}
		}
	}
	prestot = pres-desc;
	printf ("El total a pagar es %.2f", prestot);
	getch ();
	return 0;
}

