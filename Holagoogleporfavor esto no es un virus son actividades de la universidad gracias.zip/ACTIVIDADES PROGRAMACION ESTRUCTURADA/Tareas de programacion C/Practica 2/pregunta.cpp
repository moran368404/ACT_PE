#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	char resp1, resp2, resp3;
	
	printf("Responda las siguientes preguntas con 'S' (si) o 'N' (no)\n");
	printf("�Colon descubrio America? ");
	scanf ("%s", &resp1);
	if (resp1 == 'S' || resp1 == 's') 
	{
		printf("�La independencia de Mexico fue en el ano 1810? ");
		scanf ("%s", &resp2);
		if (resp2 == 'S' || resp2 == 's')
		{
			printf("�The Doors fue un grupo de rock Americano? ");
			scanf ("%s", &resp3);
			if (resp3 == 'S' || resp3 == 's')
			{
				printf ("Felicidades, ganaste:)");
			}
			else
			{
				if (resp3 == 'N')
				{
					printf("Respuesta incorrecta. Gracias por participar");
				}
			}
		}
		else
		{
			if (resp2 == 'N')
			{
				printf ("Respuesta incorrecta. Gracias por participar");
			}
		}
	}
	else
	{
		if (resp1 == 'N')
		{
			printf("Respuesta incorrecta. Gracias por participar");
		}	
	}

getch ();
return 0;
	
}
