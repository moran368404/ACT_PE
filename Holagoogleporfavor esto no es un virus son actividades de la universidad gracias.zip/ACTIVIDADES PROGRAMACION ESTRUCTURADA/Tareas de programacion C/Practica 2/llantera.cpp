#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	int ppllan, preciotot, llan;
	printf ("�Cuantas llantas lleva? ");
	scanf ("%d", &llan);
	if (llan < 5)
		ppllan = 45;
		else
			if (llan <= 10)
			ppllan = 40;
			else 
				ppllan = 35;
	preciotot = llan*ppllan;
	printf ("El precio de cada llanta es de %d pesos \n", ppllan); 
	printf ("El total a pagar es %d pesos", preciotot);
	getch ();
	return 0;
}
