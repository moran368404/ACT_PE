#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float ca, prest, ins, presu;
	int eq, mob;
	printf ("�En cuanto se encuentra su capital ahora? ");
	scanf ("%f", &ca);
	eq = 5000;
	mob = 2000;
	if (ca < 0)
	{
		prest = ((-1)*ca)+10000;
		ca = ca+prest;
	}
	else
	{
		if (ca < 20000)
		{
			prest= 20000-ca;
			ca = ca+prest;
		}
		else
		{
			ca = ca;
		}
	}
	presu = ca - eq - mob;
	ins = presu/2;
	
	printf ("Se destinaran %.2f para la compra de insumos\n", ins);
	printf ("Mientras que la otra mitad (%.2f) se utilizara para incentivos al personal\n", ins);
	if (prest > 0)
	{
		printf ("\nEl prestamo fue de %.2f", prest);
		printf ("\nMuchas gracias, que tenga buen dia");
	}
	else
	{
		printf ("\nMuchas gracias, que tenga buen dia");
	}
}
