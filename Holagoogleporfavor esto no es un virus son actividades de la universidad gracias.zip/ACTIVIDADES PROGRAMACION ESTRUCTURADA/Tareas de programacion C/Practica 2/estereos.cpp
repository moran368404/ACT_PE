#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main()
{
	float pres, prestot, desc, IVA, presest;
	char mar;
	printf ("�Cual es el precio del aparato?\n");
	scanf ("%f", &pres);
	if (pres >= 2000)
	{
		desc=pres*.1;
		pres=pres-desc;
	}
	else
	{
		pres=pres;
	}
	printf ("�El estereo es marca Nosy? Escriba 'S' para si, 'N' para no\n");
	scanf ("%s", &mar);
	
	if (mar == 'S' || mar == 's')
	{
		desc=pres*.05;
		presest=pres-desc;
		IVA=presest*.08;
		prestot=presest+IVA;
		printf ("Su total a pagar sera %.2f", prestot);
	}
	else
	{
		if (mar == 'N' || mar == 'n')
		{
			pres=pres;
			IVA=pres*.08;
			prestot=pres+IVA;
			printf ("Su total a pagar sera %.2f", prestot);
		}
		else
		{
			printf("Esta no es una opcion, el programa se cerrara");
		}
	}
	getch();
	return 0;
}
