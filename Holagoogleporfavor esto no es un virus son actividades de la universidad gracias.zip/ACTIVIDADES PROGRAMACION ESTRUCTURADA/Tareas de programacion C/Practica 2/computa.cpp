#include <stdio.h>
#include <conio.h>
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
int main ()
{
	float desc, preciotot, precioco;
	int compra, compu;
	printf("�Cuantas computadoras son? ");
	scanf("%d", &compu);
	precioco = 3500;
	compra = precioco*compu;
	if (compu < 5)
		desc = compra*.10;
		else
		if (compu < 10)
			desc = compra*.20;
			else
				desc = compra*.40;
	preciotot = compra-desc;
	printf ("El precio a pagar es: %.2f pesos", preciotot);
	getch();
	return 0;
}
