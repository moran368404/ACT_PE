#include <stdio.h>
#include <conio.h>

int main ()
{
	float tc,dlls,p;
	printf("Dime a como esta el tipo de cambio ");
	scanf("%f",&tc);
	printf("Dime la cantidad de dolares a cambiar ");
	scanf("%f",&dlls);
	p=dlls*tc;
	printf("En %.2f dolares el %.2f el tipo de cambio son %.2f pesos", dlls,tc,p);
	getch();
	return 0;
}
