#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#define p printf
#define s scanf


//****************************************************//
//    <3 Hecho por: Bianca Noelia Orozco Mor�n <3     //
// Matr�cula: 368404  Grupo:24   Pr�ctica: Reg-Linl.  //
//****************************************************//

int main(){
	float xi[15], yi[15], xi2[15], xiyi[15], sumx, sumy, sumx2, sumxiyi, medx, medy, a0, a1,n;
	int i;
	
	p("%cCu%cntos valores de xi tiene? ",168,160);
	s("%f",&n);
	
	p("Llene los valores de xi:\n");
	for (i=0;i<n;i++){
		p("Xi = ");
		s("%f",&xi[i]);
		sumx=sumx+xi[i];
	}
	
	p("Llene los valores de yi:\n");
	for(i=0;i<n;i++){
		p("Yi = ",i);
		s("%f",&yi[i]);
		sumy=sumy+yi[i];
	}
	
	// Xi2
	for(i=0;i<n;i++){
		xi2[i]=pow(xi[i],2);
		
		sumx2= sumx2 + xi2[i];
	}
	
	// Xiyi
	for(i=0;i<n;i++){
		xiyi[i]=xi[i]*yi[i];
		
		sumxiyi= sumxiyi + xiyi[i];
	}
	
	medx=sumx/n;
	medy=sumy/n;
	
	a1= ((n*sumxiyi)-(sumx*sumy)) / ((n*sumx2)-pow(sumx,2));
	a0= medy-(a1*medx);
	
	system("cls");
	
	p("El ajuste de m%cnimos cuadrados es:\n",161);
	p("y = %.5f + %.5fx\n",a0,a1);

	p("\n{ Xi         Yi       Xi2       XiYi }\n");	
	for(i=0;i<n;i++){
		p("%.4f     %.4f     %.4f    %.4f\n",xi[i],yi[i],xi2[i],xiyi[i]);
	}
	
}
