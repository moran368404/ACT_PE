#include <stdio.h>
#include <conio.h>
#include <math.h>
#include <stdlib.h>
#define p printf
#define s scanf


//****************************************************//
//    <3 Hecho por: Bianca Noelia Orozco Mor�n <3     //
// Matr�cula: 368404  Grupo:24   Pr�ctica: Reg-Expo.  //
//****************************************************//

int main(){
	float xi[15], yi[15], yj[15], xi2[15], xiyj[15], sumx, sumy, sumyj, sumx2, sumxiyj, n, B, medx, medyj, Aj, A;
	int i;
	
	p("%cCu%cntos valores de xi tiene? ",168,160);
	s("%f",&n);
	
	p("Llene los valores de xi:\n");
	for (i=0;i<n;i++){
		printf ("Xi = ");
		scanf("%f",&xi[i]);
		
		sumx=sumx+xi[i];
	}
	
	p("Llene los valores de yi:\n");
	for(i=0;i<n;i++){
		p("Yi = ",i);
		s("%f",&yi[i]);
		
		sumy=sumy+yi[i];
	}
	
	// Y'
	for (i=0;i<n;i++){
		yj[i]=log(yi[i]);
		
		sumyj=sumyj+yj[i];
	}
	
	// Xi2
	for(i=0;i<n;i++){
		xi2[i]=pow(xi[i],2);
		
		sumx2= sumx2 + xi2[i];
	}
	
	// Xi*Y'
	for (i=0;i<n;i++){
		xiyj[i]=xi[i]*yj[i];
		
		sumxiyj=sumxiyj+xiyj[i];
	}

	B = ((n*sumxiyj)-(sumx*sumyj)) / ((n*sumx2)-pow(sumx,2));
	
	medx=sumx/n;
	medyj=sumyj/n;
	
	Aj = medyj - (B*medx);
	A = exp(Aj);
	
	system("cls");
	
	p("El ajuste por regresion exponencial es:\n");
	p("y = %f + exp(%fx)\n",A,B);
	
	p("\n{ Xi         Yi         Y'       Xi2       XiY' }\n");	
	for(i=0;i<n;i++){
		p("%.4f     %.4f     %.4f    %.4f    %.4f\n",xi[i],yi[i],yj[i],xi2[i],xiyj[i]);
	}
	
}
