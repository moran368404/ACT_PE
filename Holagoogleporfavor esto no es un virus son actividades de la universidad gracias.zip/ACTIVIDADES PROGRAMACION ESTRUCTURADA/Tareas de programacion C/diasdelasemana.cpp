#include <stdio.h>
#include <conio.h>

int main ()
{
	int n;
	printf ("Dame y numero de dia ");
	scanf ("%d",&n);
	if (n==1)
	{
		printf ("DOMINGO");
	}
	else
	{
		if (n==2)
		{
			printf ("SABADO");
		}
		else
		{
			if (n==3)
			{
				printf ("VIERNES");
			}
			else
			{
				if (n==4)
				{
					printf ("JUEVES");
				}
				else
				{
					if (n==5)
					{
						printf ("MIERCOLES");
					}
					else
					{
						if (n==6)
						{
							printf ("MARTES");
						}
						else
						{
							if (n==7)
							{
								printf ("LUNES");
							}
						}
					}
				}
			}
		}
	}
	getch ();
	return 0;
}
