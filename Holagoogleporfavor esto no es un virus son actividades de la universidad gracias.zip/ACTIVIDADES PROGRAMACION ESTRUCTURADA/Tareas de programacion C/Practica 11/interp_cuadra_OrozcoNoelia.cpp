#include <stdio.h>
#include <conio.h>
#include <math.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 11.1 //
//*********************************************//

       //**Interpolacion cuadratica**//

float fun(float x);


int main(){
	float yo,yi,y2,b,b1,b2,f1,f2,fa;
	printf("Se busca saber el valor de la coordenada 5 en la funcion x^2-9, escoja dos coordenadas para obtenerlo\n");
	scanf("%f",&yo);
	printf("Escriba el segundo valor\n");
	scanf("%f",&yi);
	printf("Escriba el tercer valor\n");
	scanf("%f",&y2);
	
	b=fun(yo);
	f1=fun(yi);
	f2=fun(y2);
	
	b1=(f1-b)/(yi-yo);
	b2=((((f2-f1)/(y2-yi))-((f1-b)/(yi-yo)))/(y2-yo));
	fa=b+b1*(5-yo)+b2*(5-yo)*(5-yi);
	printf("La aproximacion a la raiz es: %f",fa);
}

float fun(float x){
	float res;
	res=pow(x,2)-9;
	return res;
}
