#include <stdio.h>
#include <conio.h>
#include <math.h>

//*********************************************//
// <3 Hecho por: Bianca Noelia Orozco Mor�n <3 //
// Matr�cula: 368404  Grupo:24   Pr�ctica 11.1 //
//*********************************************//

         //**Interpolacion lineal**//

float fun(float x);
float f1(float x,float x0,float x1,float fx0,float fx1);

int main(){
	float y,y1,y0,fy,fy1,fy0,ea;
	int n=0;
	printf("Este c%cdigo usa la f%crmula: (x%c2)-9",162,162,94);
	printf("\nDato que quieres que busque: ");
	scanf("%f",&y);
	printf("Intervalo 1: ");
	scanf("%f",&y0);
	printf("Intervalo 2: ");
	scanf("%f",&y1);
	
	fy0=fun(y0);
	fy1=fun(y1);
	fy=f1(y,y0,y1,fy0,fy1);
	
	printf("La aproximacion es de: %f",fy);
}

float fun(float x){
	float res;
	res=pow(x,2)-9;
	return res;
}
float f1(float x,float x0,float x1,float fx0,float fx1){
	float res;
	res=fx0+(x-x0)*((fx1-fx0)/(x1-x0));
	return res;
}

