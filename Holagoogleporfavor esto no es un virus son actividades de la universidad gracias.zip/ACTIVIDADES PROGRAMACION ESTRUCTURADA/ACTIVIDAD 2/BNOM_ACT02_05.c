// BNOM_ACT02_05
// Algoritmo que sirva para calcular el volumen de un cilindro
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#include <math.h>
#define p printf
#define s scanf
#define pi 3.1416

int main(){
	int r,h;
	float res;
	
	p("Dame la medida del radio: ");
	s("%d",&r);
	p("Dame la medida de la altura: ");
	s("%d",&h);
	
	res=(pi*(pow(r,2)))*h;
	
	p("El volumen del cilindro es %.2f",res);
	
	}

