// BNOM_ACT02_01
// Algoritmo que lea edad de una persona (en a�os enteros) desplegar su edad en meses y d�as
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#define p printf
#define s scanf

int main (){
	int edad, dias=365,meses=12;
	
	
	p("Dame tu edad. ");
	s("%d",&edad);
	
	meses=edad*meses;
	dias=edad*dias;
	
	p("\nTu edad en meses:  %d y en dias: %d",meses,dias);	
}

