// BNOM_ACT02_02
// Algoritmo que lea el precio y la cantidad de un art�culo que vas a comprar y calcular: Subtotal, Iva (16%) y el total a pagar
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#define p printf
#define s scanf
#define IVA .16

int main(){
	float precio,subt,tot;
	int cant;
	
	p("�Cuantos articulos va a comprar? ");
	s("%d",&cant);
	p("Precio: ");
	s("%f",&precio);
	
	subt=cant*precio;
	tot=subt+(subt*IVA);
	
	p("El subtotal de su compra seria %.2f, y el total a pagar seria %.2f",subt,tot);
	
	}
	

