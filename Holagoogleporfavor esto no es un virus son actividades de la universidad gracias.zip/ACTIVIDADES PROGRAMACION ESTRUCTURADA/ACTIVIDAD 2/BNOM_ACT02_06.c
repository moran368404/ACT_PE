// BNOM_ACT02_06
// Determina el costo del pasto, cantidad de alambre para cercar un terreno
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#define p printf
#define s scanf


int main(){
	float a,b,area,pasto,cerca;
	float res;
	
	p("Dame la medida del largo del terreno: ");
	s("%f",&a);
	p("Dame la medida del ancho del terreno: ");
	s("%f",&b);
	
	area = a*b;
	pasto = area*35.40;
	cerca = (2*a)+(2*b);
	
	
	p("El costo de sembrar el pasto sera: %.2f pesos\n",pasto);
	p("La cantidad de alambre que se va a ocupar son: %.2f metros", cerca);
	
	}
