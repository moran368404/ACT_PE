// BNOM_ACT02_04
// Algoritmo que sirva para calcular el �rea de un trapecio
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#include <math.h>
#define p printf
#define s scanf

int main(){
	int B,b,h;
	float res;
	
	p("Dame la medida de la base larga: ");
	s("%d",&B);
	p("Dame la medida de la base corta: ");
	s("%d",&b);
	p("Dame la medida de la altura: ");
	s("%d",&h);	
	
	res=((B*b)*h)/2;
	
	p("El area del trapecio es %.2f",res);
	
	
	}
