// BNOM_ACT02_07
// Teorema de pitagoras
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#include <math.h>
#define p printf
#define s scanf

int main (){
	float a,b,c;
	
	p("Dame el cateto a: ");
	s("%f",&a);
	p("Dame el cateto b: ");
	s("%f",&b);
	
	c= sqrt(pow(a,2)+pow(b,2));
	
	p("La hipotenusa vale %f",c);	
}
