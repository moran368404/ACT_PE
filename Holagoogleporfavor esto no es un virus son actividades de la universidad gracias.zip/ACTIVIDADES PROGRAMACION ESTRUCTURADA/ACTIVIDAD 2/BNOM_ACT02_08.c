// BNOM_ACT02_08
// Algoritmo para calcular cu�ntas horas ha dormido una persona durante toda su vida, considerando que todos los a�os tienen 365 d�as.
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#define p printf
#define s scanf

int main (){
	int edad,hrs=8760,hrs_mimi;
	
	p("Dame tu edad: ");
	s("%d",&edad);
	
	hrs_mimi = (hrs * edad)/3;
	
	p("Usted ha dormido %d hrs en toda su vida",hrs_mimi);	
}
