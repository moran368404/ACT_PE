// BNOM_ACT02_03
// Algoritmo que sirva para calcular el �rea de un cuadrado
// BIANCA NOELIA OROZCO MORAN 368404
// 19 DE AGOSTO DEL 2022

#include <stdio.h>
#include <math.h>
#define p printf
#define s scanf

int main(){
	int l;
	float res;
	
	p("Dame la medida de un lado: ");
	s("%d",&l);
	
	res=pow(l,2);
	
	p("El area del cuadrado es %.2f",res);
	
	
	}
	
