// BNOM_ACT03_09
// Algoritmo que lea 3 n�meros y desplegar los 3 n�meros en orden ascendente
// Bianca Noelia Orozco Mor�n 368404
// 26 de agosto del 2022

#include <stdio.h>
#define p printf
#define s scanf

int main ()
{
	int num1, num2, num3;
	
	p("DAME 3 NUMEROS: ");
	s("%d",&num1);
	s("%d",&num2);
	s("%d",&num3);
	
	if (num1 > num2)
	   {
	   	if (num1 > num3)
	   	   {
	   	   	if (num2 > num3)
	   	   	   {
	   	   	   		p("%d - %d - %d",num3, num2, num1);
			   }
			   else
			   {
			   		p("%d - %d - %d",num2, num3, num1);
			   }
		   }
		   else
		   {
		   		p("%d - %d - %d",num2, num1, num3);
		   }
	   }
	   else
	   {
	   	if (num2 > num3)
	   	   {
	   	   	if (num1 > num3)
	   	   	   {
	   	   	   		p("%d - %d - %d",num3, num1, num2);
			   }
			   else
			   {
			   		p("%d - %d - %d",num1, num3, num2);
			   }
		   }
		   else
		   {
		   		p("%d - %d - %d",num1, num2, num3);
		   }
	   }

}
