// BNOM_ACT03_02
// Algoritmo que lea un n�mero entero, y desplegar si el n�mero es �PAR� o �IMPAR�
// Bianca Noelia Orozco Mor�n 368404
// 26 de agosto del 2022

#include <stdio.h>
#define p printf
#define s scanf

int main ()
{
	int num;
	
	p("DAME UN NUMERO: ");
	s("%d",&num);
	
	if (num % 2 == 0)
	   {
	   		p("EL NUMERO ES PAR");
	   }
	if (num % 2 != 0)
	   {
	   		p("EL NUMERO ES IMPAR");
	   }
}
