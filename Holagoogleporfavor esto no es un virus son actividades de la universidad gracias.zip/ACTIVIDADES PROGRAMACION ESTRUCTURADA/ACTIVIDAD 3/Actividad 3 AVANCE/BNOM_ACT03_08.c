// BNOM_ACT03_08
// Algoritmo que lea 3 n�meros y desplegar cu�l n�mero es del medio y su valor
// Bianca Noelia Orozco Mor�n 368404
// 26 de agosto del 2022

#include <stdio.h>
#define p printf
#define s scanf

int main ()
{
	int num1, num2, num3;
	
	p("DAME 3 NUMEROS: ");
	s("%d",&num1);
	s("%d",&num2);
	s("%d",&num3);
	
	if (num1 > num2)
	   {
	   	if (num1 > num3)
	   	   {
	   	   	if (num2 > num3)
	   	   	   {
	   	   	   		p("EL NUMERO DE EN MEDIO ES %d", num2);
			   }
			   else
			   {
			   		p("EL NUMERO DE EN MEDIO ES %d", num3);
			   }
		   }
		   else
		   {
		   		p("EL NUMERO DE EN MEDIO ES %d", num1);
		   }
	   }
	   else
	   {
	   	if (num2 > num3)
	   	   {
	   	   	if (num1 > num3)
	   	   	   {
	   	   	   		p("EL NUMERO DE EN MEDIO ES %d", num1);
			   }
			   else
			   {
			   		p("EL NUMERO DE EN MEDIO ES %d", num3);
			   }
		   }
		   else
		   {
		   		p("EL NUMERO DE EN MEDIO ES %d", num2);
		   }
	   }

}
