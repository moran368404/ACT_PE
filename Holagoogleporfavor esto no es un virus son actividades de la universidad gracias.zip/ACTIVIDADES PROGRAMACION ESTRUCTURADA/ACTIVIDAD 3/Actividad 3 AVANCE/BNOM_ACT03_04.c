// BNOM_ACT03_04
// Algoritmo que a trav�s de opciones (1.- HOMBRE 2.- MUJER ) preguntar al usuario cual es su SEXO y desplegar la leyenda �HOLA, ERES HOMBRE �, � HOLA, ERES MUJER�
// Bianca Noelia Orozco Mor�n 368404
// 26 de agosto del 2022

#include <stdio.h>
#define p printf
#define s scanf

int main ()
{
	int op;
	
	p("ESCRIBA SU SEXO (1.- HOMBRE, 2.- MUJER): ");
	s("%d",&op);
	
	if (op == 1)
	   {
	   		p("HOLA, ERES HOMBRE");
	   }
	   else
	   {
	   	if (op == 2)
	   	   {
	   	    	p("HOLA, ERES MUJER");
		   }
	   }
}
