// BNOM_ACT03_01
// Algoritmo que lea 4 calificaciones de un alumno, calcular y desplegar el promedio acompa�ado de la leyenda APROBADO o REPROBADO (CONDICION SIMPLE)
// Bianca Noelia Orozco Mor�n 368404
// 26 de agosto del 2022

#include <stdio.h>
#define p printf
#define s scanf

int main ()
{
	int cal1,cal2,cal3,cal4,prom;
	
	p("DAME 4 CALIFIACIONES: ");
	s("%d",&cal1);
	s("%d",&cal2);
	s("%d",&cal3);
	s("%d",&cal4);
	
	prom = (cal1 + cal2 + cal3 + cal4) / 4;
	
	if (prom >= 60)
	   {
			p("APROBADO CON UN PROMEDIO DE %d", prom);
	   }
	if (prom < 60)
	   {
			p("REPROBADO CON UN PROMEDIO DE %d",prom);
	   }
}
