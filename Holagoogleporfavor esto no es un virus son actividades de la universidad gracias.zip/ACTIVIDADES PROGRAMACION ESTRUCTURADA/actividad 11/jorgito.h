// BNOM_ACT10_CODIGO
// MI LIBRERIA 
// BIANCA NOELIA OROZCO MORAN, 368404
// 14 DE OCTUBRE 2022

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define N 2000

//****************************************************************
// CAPITAL
void cap(char *cadena)
{
    //  VARIALES LOCALES 
    int i;
    //  AQUI DESARROLLO PROGRAMA
	if (cadena[0] >= 'a' && cadena[0] <= 'z')
	   		   {
	   		   		cadena[i] -= 32;
			   }

	for(i=1;cadena[i]!='\0';i++)
	   {
	   		if (cadena[i] >= 'A' && cadena[i] <= 'Z')
	   		   {
	   		   		cadena[i] += 32;
			   }
	   }
}

//****************************************************************
// CAPITAL
void mayusculas(char *cadena)
{
    //  VARIALES LOCALES 
    int i;
	for(i=0;cadena[i]!='\0';i++)
	   {
	   		if (cadena[i] >= 'a' && cadena[i] <= 'z')
	   		   {
	   		   		cadena[i] -= 32;
			   }
	   }
}

//****************************************************************
// VALIDACION DE NUMEROS ENTEROS
int validNum(int ri, int rf, char msge[], char msgeError[])
{
	int num;
	char xnum[30];
	do
	{
		puts(msge);
		fflush(stdin);
		gets(xnum);
		num = atoi(xnum);
		if(num < ri || num > rf) 
		  {
		  		printf("%s",msgeError);
		  		printf("\n");
		  }
	} while(num < ri || num > rf);
	
	return num;
}

//****************************************************************
// VALIDACION DE NUMEROS LONG
int validLong(long ri, long rf, char msge[], char msgeError[])
{
	long num;
	char xnum[30];
	do
	{
		puts(msge);
		fflush(stdin);
		gets(xnum);
		num = atoi(xnum);
		if(num < ri || num > rf) 
		  {
		  		printf("%s",msgeError);
		  		printf("\n");
		  }
	} while(num < ri || num > rf);
	
	return num;
}

//****************************************************************
// VALIDACION DE CADENAS
void validCad(char *cadena,char msge[])
{
	int i=0;
	char ola;
	puts(msge);
	do
	{
		ola = getc(stdin);
		if((ola>='a' && ola<='z') || (ola>='A' && ola<='Z' || ola == ' '))
		  {
		  		if (cadena[i-1] == ' ' && ola == ' ')
		  		   {
				   }
				   else
				   {
				   		if (ola == ' ' && i == 0)
						   {
						   }
						   else
						   {
						   		cadena[i] = ola;
		  		    			i++;
						   }
				   }
		  }
	} while (ola!='\n');
	if (cadena[i-1] == ' ')
	   {
	   		cadena[i-1] = '\0';
	   }
	cap(cadena);
	cadena [i] = '\0';
}

void validCadNum(char *cadena,char msge[])
{
	int i=0;
	char ola;
	puts(msge);
	do
	{
		ola = getc(stdin);
		if((ola>='a' && ola<='z') || (ola>='A' && ola<='Z' || ola == ' ' || (ola>='0' && ola<='9')))
		  {
		  		if (cadena[i-1] == ' ' && ola == ' ')
		  		   {
				   }
				   else
				   {
				   		if (ola == ' ' && i == 0)
						   {
						   }
						   else
						   {
						   		cadena[i] = ola;
		  		    			i++;
						   }
				   }
		  }
	} while (ola!='\n');
	if (cadena[i-1] == ' ')
	   {
	   		cadena[i-1] = '\0';
	   }
	mayusculas(cadena);
	cadena [i] = '\0';
}

