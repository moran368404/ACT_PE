//menu.h
#include "jorgito.h"

#define ENTER 13
#define TAB 9
#define ARRIBA 72
#define ABAJO 80
#define DERECHA 77
#define IZQUIERDA 75

#define RED     "\x1b[31m"
#define GREEN   "\x1b[32m"
#define YELLOW   "\x1b[33m"
#define BLUE    "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN    "\x1b[36m"
#define RESET   "\x1b[0m"

unsigned int msges(char titulo[],char opciones[][30],unsigned int n)
{
	int op,i;
	char tecla;
	//op = validNum(0,n,"ESCOGE UNA OPCION: ","ESA OPCION NO ESTA EN EL MENU");
	op=0;
	do
	{
		system("cls");
		printf(GREEN "******** %s ********\n" RESET,titulo);
		for(i=0;i<n;i++)
		{
			if(i==op)
				printf(YELLOW "%d.- %s\n" RESET,i+1,opciones[i]);
			else
				printf("%d.- %s\n",i+1,opciones[i]);
		}
		printf("Utiliza las flechas y <Enter> para seleccionar.\n");
		tecla = getch();
		//printf("%d",car);
		
		switch(tecla)
		{
			case DERECHA:
			case ABAJO:
				if (op == (n-1))
				{
					op = -1;
				}
			op++;
			break;
			case ARRIBA:
			case IZQUIERDA:
				if (op == 0)
				{
					op = n;
				}
			op--;
			break;
			case '1':
				op=0;
			break;
			case '2':
				op=1;
			break;
			case '3':
				op=2;
			break;
			case '4':
				op=3;
			break;
			case '5':
				op=4;
			break;
			case '6':
				op=5;
			break;
			case '7':
				op=6;
			break;
			case '8':
				op=7;
			break;
			case '9':
				op=8;
			break;
			case '0':
				op=9;
			break;
			default:
				break;
		}
	} while (tecla != ENTER);

	return (op+1);
}
unsigned int menu(char titulo[],char opciones[][30],unsigned int n)
{
	return(msges(titulo,opciones,n));
}
