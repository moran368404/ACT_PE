#include <stdio.h>
#include <stdlib.h>

void GeneraCurp(char c1[], char c2[], char ap[],char am[], char Fc[],int sexo, char EntFed[],char curp[])
{
	char dv[3];
	int i,sal=false,ano,numrandom;
	if(strstr(ap,"DE LA ")==NULL)
		curp[0] = ap[0];
	else
	{
		strcpy(ap,&ap[6]);
		curp[0]=ap[0];
	}
	i=1;
	do
	{
		if(ap[i]=='A' || ap[i]=='E' || ap[i]=='I' || ap[i]=='O'|| ap[i]=='U') 
		{
			curp[1]=ap[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	if(strcmp(am,"")==0) // SI NO HAY NADA EN EL SEGUNDO APELLIDO, PONER UNA X
	{
		curp[2]='X';
	}
	else
	{
		if(strstr(am,"DE LA ")==NULL)
			curp[2] = am[0];
		else
		{
			strcpy(am,&am[6]);
			curp[2]=am[0];
		}
	}
	if(strcmp(c1,"JOSE")==0 && strcmp(c2,"")!=0) // SI EL NOMBRE ES COMPUESTO, Y EL PRIMERO ES JOSE
	{
		strcpy(c1,c2);
	}
	
	if(strcmp(c1,"MARIA")==0 && strcmp(c2,"")!=0) // SI EL NOMBRE ES COMPUESTO, Y EL PRIMERO ES MARIA
	{
		strcpy(c1,c2);
	}
	
	curp [3] = c1[0];
	curp [4] = Fc[6];
	curp [5] = Fc[7];
	curp [6] = 	Fc[2];
	curp [7] = Fc[3];
	curp [8] = Fc [0];
	curp [9] = Fc[1];
	curp [10] = (sexo==true)?'M':'H';
	curp [11] = EntFed[0];
	curp [12] = EntFed[1];
	//curp[13] = '\0';
	fflush(stdin);
	//system("cls");
	//printf("\nEL CURP ES: ");
	
	
	sal = false;
	i=1;
	do
	{
		if(ap[i]=='A' || ap[i]=='E' || ap[i]=='I' || ap[i]=='O'|| ap[i]=='U') 
		{
		}
		else
		{
			curp[13]=ap[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	
	if (strcmp(am,"")!=0)
	{
		sal = false;
		i=1;
		do
		{
			if(am[i]=='A' || am[i]=='E' || am[i]=='I' || am[i]=='O'|| am[i]=='U') 
			{
			}
			else
			{
				curp[14]=am[i];
				sal = true;
			}
			if(i==strlen(am))
			{
				curp[14]='X';
				sal=true;
				//printf("Si esta entrando....");
			}
		i++;
		}while(sal == false);
	}
	else
	{
		curp[14]='X';
	}
	
	sal = false;i=1;
	do
	{
		if(c1[i]=='A' || c1[i]=='E' || c1[i]=='I' || c1[i]=='O'|| c1[i]=='U') 
		{
		}
		else
		{
			curp[15]=c1[i];
			sal = true;
		}
	i++;
	}while(sal == false);
	// PONE LA LETRA O SI EL A;O ES MENOR A 2000 Y A SI ES DESPUES DEL 2000
	ano=atoi(&Fc[4]);
	if(ano<2000)
	{
		curp[16]='O';
	}
	else
	{
		curp[16]='A';
	}
	// PONE UN NUMERO ALEATORIO ENTRE EL 1 Y EL 9 AL ULTIMO CARACTER
	numrandom=(rand()%9)+1;
	itoa(numrandom,dv,10);
	curp[17]=dv[0];
	// PONE UNA X EN LUGAR DE LA/S �
	for(i=0;i<16;i++)
	{
		if (curp[i]==-92 || curp[i]==-91 || curp[i]=='�' || curp[i]=='�')
		{
			curp[i]='X';
		}
	}
	
	// CENSURA DE PALABRAS ALTISONANTES
	if(curp [0] == 'P' && curp[1]=='E' && curp[2]=='N' && curp [3]=='E')
	{
		curp[1]='X';
	}
	if(curp [0] == 'T' && curp[1]=='E' && curp[2]=='T' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='U' && curp[2]=='L' && curp [3]=='O')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='I' && curp[2]=='J' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='U' && curp[2]=='T' && curp [3]=='O' && curp[3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='U' && curp[2]=='C' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'P' && curp[1]=='I' && curp[1]=='O' && curp[2]=='P' && curp [3]=='I' && curp [3]=='O')
	{
		curp[1]='X';
	}
	if(curp [0] == 'C' && curp[1]=='A' && curp[2]=='C' && curp [3]=='A')
	{
		curp[1]='X';
	}
	if(curp [0] == 'F' && curp[1]=='U' && curp[2]=='C' && curp [3]=='K')
	{
		curp[1]='X';
	}
	if(curp [0] == 'A' && curp[1]=='N' && curp[2]=='O' && curp [3]=='S')
	{
		curp[1]='X';
	}
	if(curp [0] == 'F' && curp[1]=='A' && curp[2]=='L' && curp [3]=='O')
	{
		curp[1]='X';
	}
	
	// IMPRIME EL CURP LETRA POR LETRA
	//printf("\n");
	//for(i=0;i<18;i++)
	//{
	//	printf("%c",curp[i]);
	//}
	//printf("\n");
}
