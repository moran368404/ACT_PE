#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<stdbool.h>
#include<time.h>

#include "generacurp.h"
#include "leerdatos.h"
#include "menu.h"

struct TNombre
{
	char Nombre1[30];
	char Nombre2[30];
	char ApPat[30];
	char ApMat[30];
};
typedef struct _alumnos
{
	char status;
	long id;
	struct TNombre nomc;
	char sexo;
	char fnac[10];
	char lnac[30];
	int edad;
	char curp[19];
}TSAlumnos;

TSAlumnos GenDatRand ();

int main()
{
	TSAlumnos Datos[N],temporal;
	long matricula;
	int i,indice=0,j;
	bool salir = false;
	bool ordenados_curp=false;
	bool ordenados_nombre=false;
	bool ordenados_matricula=false;
	bool encontrado=false;
	char curp[19];
	char opciones_del_menu[][30]={"Cargar","Buscar por Matricula","Buscar por CURP",
						"Ordenar por nombre","Ordenar por CURP","Ordenar por Matricula","Imprimir","Salir"};

	do
	{
		unsigned int op=menu("Menu",opciones_del_menu,8);
		printf("selecciono: %d\n",op);
		switch(op)
		{
			case 8: salir=true;
			break;
			case 1: //Cargar
				printf("Selecciono %s\n",opciones_del_menu[0]);
				for(i=0;i<100;i++)
				{
					if(indice<N)
					{
						Datos[indice]=GenDatRand();
						indice++;
						if(ordenados_curp==true)
							ordenados_curp=false;
						if(ordenados_nombre==true)
							ordenados_nombre=false;
						if(ordenados_matricula==true)
							ordenados_matricula=false;
					}
				}
				if(indice>=N)
					printf("Buffer lleno...\n");

				printf("Hay %d datos\n",indice);
				system("pause");
			break;
			case 2: //Buscar por matricula ***SECUENCIAL***
				encontrado=false;
				printf("Selecciono %s\n",opciones_del_menu[1]);
				matricula = validLong(0, 100000000, "Dame tu matricula: ", "Esa matricula no es valida");
				if(ordenados_matricula==false) //se utiliza busqueda secuencial
				{
					for(i=0;(i<indice)&&(encontrado==false);i++)
					{
						if(matricula==Datos[i].id)
						{
							printf("****** REGISTRO ENCONTRADO *******\n");
							printf("Matricula 1er Nombre   2do Nombre   Ap.Paterno   Ap.Materno  Edad Sexo LugarNac CURP\n");
							printf("%d.- %8d %10s %10s %10s %10s %d\t%c\t%20s %20s\n",i,Datos[i].id,Datos[i].nomc.Nombre1,Datos[i].nomc.Nombre2,Datos[i].nomc.ApPat,Datos[i].nomc.ApMat,Datos[i].edad,Datos[i].sexo,Datos[i].lnac,Datos[i].curp);
							encontrado=true;
						}
					}
					if(encontrado==false)
						printf("******* REGISTRO NO ENCONTRADO *******\n");
				}
				else
				{
					//Poner aqui busqueda binaria por matricula
				}
				system("pause");
			break;
			case 3: //Buscar por CURP 
					//Si est�n ordenados por CURP, realiza b�squeda binaria
					//Si est�n ordenados por Nombre, realiza b�squeda secuencial
					//Si no est�n ordenados realizar� b�squeda secuencial
				printf("Selecciono %s\n",opciones_del_menu[2]);
				if(ordenados_curp==true)
				{
					//b�squeda binaria
					// falta agregar busqueda binaria
				}
				else
				{
					//b�squeda secuencial
					encontrado=false;
					printf("Selecciono %s\n",opciones_del_menu[1]);
					validCadNum(curp,"Dame CURP para buscar: ");
					printf("buscando %s\n",curp);
					for(i=0;(i<indice)&&(encontrado==false);i++)
					{
						if(strstr(Datos[i].curp,curp)!=NULL)
						{
							printf("****** REGISTRO ENCONTRADO *******\n");
							printf("Matricula 1er Nombre   2do Nombre   Ap.Paterno   Ap.Materno  Edad Sexo LugarNac CURP\n");
							printf("%d.- %8d %10s %10s %10s %10s %d\t%c\t%20s %20s\n",i,Datos[i].id,Datos[i].nomc.Nombre1,Datos[i].nomc.Nombre2,Datos[i].nomc.ApPat,Datos[i].nomc.ApMat,Datos[i].edad,Datos[i].sexo,Datos[i].lnac,Datos[i].curp);
							encontrado=true;
						}
					}
					if(encontrado==false)
						printf("******* REGISTRO NO ENCONTRADO *******\n");
				} 
				system("pause");
			break;
			case 4: //Ordenar por nombre
					//***** METODO DE BURBUJA *****
				printf("Selecciono %s\n, ordenamiento por BURBUJA",opciones_del_menu[3]);
				if(ordenados_nombre==false)
				{
					for(i=1;i<indice;i++)
					{
						for(j=0;j<=(indice-2);j++)
						{
							if(strcmp(Datos[j].nomc.Nombre1,Datos[j+1].nomc.Nombre1)>0)
							{
								temporal=Datos[j];
								Datos[j]=Datos[j+1];
								Datos[j+1]=temporal;
							}
							else if(strcmp(Datos[j].nomc.Nombre1,Datos[j+1].nomc.Nombre1)==0)
							{
								if(strcmp(Datos[j].nomc.Nombre2,Datos[j+1].nomc.Nombre2)>0)
								{
									temporal=Datos[j];
									Datos[j]=Datos[j+1];
									Datos[j+1]=temporal;
								}
								else if(strcmp(Datos[j].nomc.Nombre2,Datos[j+1].nomc.Nombre2)==0)
								{
									if(strcmp(Datos[j].nomc.ApPat,Datos[j+1].nomc.ApPat)>0)
									{
										temporal=Datos[j];
										Datos[j]=Datos[j+1];
										Datos[j+1]=temporal;
									}
								}
							}
						}
					}
				}
				else
					printf("***** NO ES NECESARIO ORDENAR POR NOMBRE OTRA VEZ ******\n");
				system("pause");
				ordenados_nombre=true;
				ordenados_curp=false;
				ordenados_matricula=false;
			break;
			case 5: //Ordenar por CURP
					//Ordenamiento por inserci�n
				printf("Selecciono %s, ordenamiento por inserci�n\n",opciones_del_menu[4]);
				if(ordenados_curp==false)
				{
					for(i=1;i<indice;i++)
					{
						j=i;
						while(j>=0 && strcmp(Datos[j].curp,Datos[j-1].curp)<0)
						{
							temporal=Datos[j];
							Datos[j]=Datos[j-1];
							Datos[j-1]=temporal;
							j--;
						}
					}
				}
				else
					printf("***** NO ES NECESARIO VOLVER A ORDENARLOS POR CURP *****\n");
				system("pause");
				ordenados_curp=true;
				ordenados_nombre=false;
				ordenados_matricula=false;
			break;
			case 6: //Ordenar por Matricula
					//Ordenamiento por inserci�n
				printf("Selecciono %s, ordenamiento por inserci�n\n",opciones_del_menu[5]);
				if(ordenados_matricula==false)
				{
					for(i=1;i<indice;i++)
					{
						j=i;
						while(j>=0 && (Datos[j].id<Datos[j-1].id))
						{
							temporal=Datos[j];
							Datos[j]=Datos[j-1];
							Datos[j-1]=temporal;
							j--;
						}
					}
				}
				else
					printf("***** NO ES NECESARIO VOLVER A ORDENARLOS POR MATRICULA *****\n");
				system("pause");
				ordenados_matricula=true;
				ordenados_curp=false;
				ordenados_nombre=false;
			break;
			case 7: //Imprimir
				printf("Selecciono %s\n",opciones_del_menu[6]);
				printf("Matricula\t1er Nombre\t2do Nombre\tAp.Paterno\tAp.Materno\tEdad\tSexo\tLugarNac CURP\n");
				for(i=0;i<indice;i++)
				{
					if(Datos[i].status=='A')
						printf("%3d.- %8d %10s %10s %10s %10s %d\t%c\t%20s %20s\n",i,Datos[i].id,Datos[i].nomc.Nombre1,Datos[i].nomc.Nombre2,Datos[i].nomc.ApPat,Datos[i].nomc.ApMat,Datos[i].edad,Datos[i].sexo,Datos[i].lnac,Datos[i].curp);
					if((i>0)&&((i%40)==0))
					{
						system("pause");
						printf("Matricula 1er Nombre   2do Nombre   Ap.Paterno   Ap.Materno  Edad Sexo LugarNac CURP\n");
					}
				}
				system("pause");
			break;
		}
	}while (!salir);
	printf("GRACIAS POR USAR EL CODIGO :)");

	return 0;
} 

TSAlumnos GenDatRand ()
{
	TSAlumnos reg;
	int sex,dia,mes,ano,lnac,nombrecompuesto,edad;
	char nom[15][20];
	char EntFed[3];
	char nomMUJ[20][15] = {"BIANCA","NOELIA","ELISA","GHIZETH","YAREMI","DANIELA","LUISA","VIVIANA","ALEJANDRA","KARLA","DOJA","SNOW","MARIA","ALEXA","ALICIA"};
	char nomHOM[20][15]  = {"JORGE","ALEJANDRO","ENRIQUE","LUIS","MIGUEL","ANGEL","SANTIAGO","SEBASTIAN","JOSE","MISAEL","ISAAC","ALI","YAEL","AXEL","JESUS","PEDRO"};
	char APE[20][15] = {"GRIMALDO","HERNANDEZ","TELLO","MORA","VILLA","JUAREZ","OROZCO","MORAN","NUNEZ","YEPIZ","SERNA","DIAZ","YANEZ","LIZAOLA","GALI"};
	char sig[][33] = {"AS","BC","BS","CC","CL","CM","CS","CH","DF",
					"DG","GT","GR","HG","JC","MC","MN","MS","NT","NL",
					"OC","PL","QT","QR","SP","SL","SR","TC","TS","TL",
					"VZ","YN","ZS","NE"};
	char cad[][33] = {"AGUASCALIENTES","BAJA CALIFORNIA",
		"BAJA CALIFORNIA SUR","CAMPECHE","COAHUILA","COLIMA","CHIAPAS",
		"CHIHUAHUA","DISTRITO FEDERAL","DURANGO","GUANAJUATO","GUERRERO",
		"HIDALGO","JALISCO","MEXICO","MICHOACAN","MORELOS","NAYARIT",
		"NUEVO LEON","OAXACA","PUEBLA","QUERETARO","QUINTANA ROO",
		"SAN LUIS POTOSI","SINALOA","SONORA","TABASCO","TAMAULIPAS",
		"TLAXCALA","VERACRUZ","YUCATAN","ZACATECAS",
		"NACIDO EN EL EXTRANJERO"};	
	//system("cls");
	// SEXO Y NOMBRE
	sex = rand()%2;
	nombrecompuesto=rand()%2;
	if(sex == 0) 
	  {
	  		strcpy(reg.nomc.Nombre1,nomMUJ[rand()%15]);
	  		if(nombrecompuesto)
	  			strcpy(reg.nomc.Nombre2,nomMUJ[rand()%15]);
  			else
	  			strcpy(reg.nomc.Nombre2,"");
	  } 
	  else 
	  {
	  		strcpy(reg.nomc.Nombre1,nomHOM[rand()%15]);
	  		if(nombrecompuesto)
	  			strcpy(reg.nomc.Nombre2,nomHOM[rand()%15]);
  			else
	  			strcpy(reg.nomc.Nombre2,"");
	  } // 0 = MUJER , 1 = HOMBRE
	  
	if (sex == 0)
	{
		reg.sexo = 'M';
	}
	else
	{
			reg.sexo = 'H';
	}
	
	// APELLIDOS
	strcpy(reg.nomc.ApPat,APE[rand()%15]);
	strcpy(reg.nomc.ApMat,APE[rand()%15]);
	
	// MATRICULA
	reg.id = rand()%70000 + 330000;
	
	// STATUS
	reg.status = 'A';
	
	// FECHA DE NACIMIENTO
	mes = rand()%12+1;
	if(mes==1 || mes==3 || mes==5 || mes==7 || mes==8 || mes==10 || mes==12)
		dia = rand () % 31 + 1;
	else if(mes==4 || mes==6 || mes==9 || mes==11)
		dia= rand()%30 + 1;
	else if(mes==2)
		dia=rand()%28+1;
	ano=rand()%10 + 2000;

	time_t t=time(NULL);
	struct tm *tm=localtime(&t);

	//printf("fecha de hoy: %d:%d:%d\n",tm->tm_mday,tm->tm_mon+1,tm->tm_year+1900);
	edad=(tm->tm_year+1900)-ano;
	if(mes>(tm->tm_mon+1) || (mes==(tm->tm_mon+1) && dia>tm->tm_mday))
		edad=edad-1;
	sprintf(reg.fnac,"%02d%02d%04d",dia,mes,ano);
	reg.edad=edad;
	lnac=rand()%33;
	strcpy(reg.lnac,cad[lnac]);
	strcpy(EntFed,sig[lnac]);
	reg.status='A';
	GeneraCurp(reg.nomc.Nombre1, reg.nomc.Nombre2, reg.nomc.ApPat,reg.nomc.ApMat, reg.fnac,sex, EntFed,reg.curp);
	//printf("Dato generado: %s %s %s %s %s %s %c %d a�os curp: %s\n",reg.nomc.Nombre1,reg.nomc.Nombre2,reg.nomc.ApPat,reg.nomc.ApMat,reg.fnac,reg.lnac,reg.sexo,reg.edad,reg.curp);
	return reg;
}

