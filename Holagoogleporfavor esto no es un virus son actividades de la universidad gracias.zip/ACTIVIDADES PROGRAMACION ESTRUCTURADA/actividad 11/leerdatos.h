#include <stdlib.h>
#define ENTER 13
#define TAB 9
#define ARRIBA 72
#define ABAJO 80
#define DERECHA 77
#define IZQUIERDA 75


void LeerNombres(char c1[], char c2[])
{
	char n1[20],n2[20],Esp[1], a[2];
	int car, i=0, DobEsp, EspI, j, Espp=0,k=0, carA;
	bool ValA=false;
	
	do{
		i=0;
		k=0;
		Espp=0;
		system ("CLS");
		printf("Ingresa Tus Nombres:");
		do{
			car=getch();
			
			if(car==8 && i!=0 && Espp==0 && k==0){
				i=i-1;
				system ("CLS");
				printf("Ingresa Tus Nombres:");
				for(j=0;j<=i-1 ;j++){
					
					printf("%c",n1[j]);
				}
			}
			if(car==8 && k!=0 && Espp==1){
				k=k-1;
				system ("CLS");
				printf("Ingresa Tus Nombres:");
				for(j=0;j<=i-1 ;j++){
					
					printf("%c",n1[j]);
				}
				for(j=0;j<=k-1 ;j++){
					
					printf("%c",n2[j]);
				}
				if(k==0){Espp=0;}
			
			}
			else{
				if(car >=97 && car <=122)
				{car = car-32;}
				if((car>=65 && car <=90) || car==32)
				{
					if(i==0 && car==' '){EspI=1;}
					if(car==' '){Espp=1;}
					else{EspI=0;}
					if(EspI==0 && Espp==0)
					{
						if(n1[i-1]==' ' && car==' '){DobEsp=1;}
						else {DobEsp=0;}
						if(DobEsp==0)
						{
							printf("%c",car);
							n1[i]=car;
							i++;
						}
					}
					if(Espp==1)
					{
						if(n1[k-1]==' ' && car==' '){DobEsp=1;}
						else {DobEsp=0;}
						if(DobEsp==0)
						{
							printf("%c",car);
							n2[k]=car;
							k++;
						}
					}
				}
			}
		}while(car!=ENTER && i!=20 && Espp!=2);
		n1[i]='\0';
		n2[k]='\0';
		fflush(stdin);
		if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
		printf("\nPrimer nombre: %s\n",n1);
		for(j=0;j<k;j++)
		{
			n2[j]=n2[j+1];
		}
		printf("Segundo nombre: %s\n",n2);
		strcpy(c1,n1);
		strcpy(c2,n2);
		printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}
//**********************************************************************************
//Leer apellido paterno
void LeerApellidoPaterno(char ap[])
{
	int car, i=0, j, a[2];
	char AP[20],Esp[1], carA;
	bool ValA=false;
	do{
		i=0;
		system ("CLS");
		printf("Ingresa Apellido Paterno:");
	
	do{
		car=getch();
		
		if(car==8 && i!=0){
			i=i-1;
			system ("CLS");
			printf("Ingresa Apellido Paterno:");
			for(j=0;j<=i-1 ;j++){
				
				printf("%c",AP[j]);
			}
		}
		else{
			if(car >=97 && car <=122)
			{car = car-32;}
			if((car>=65 && car <=90 ) || car==32)
			{
				if(i==0 && car==' ')
				{
				}
				else
				{
					if(car==' ' && AP[i-1]==' ')
					{
					}
					else
					{
						printf("%c",car);
						AP[i]=car;
						i++;
					}
				}
			}
			if(car==164 || car == 165)
			{
				printf("%c",165);
				AP[i]=165;
				i++;
			}
		}
	}while(car!=ENTER);
	AP[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\nApellido paterno: %s\n",AP);
	strcpy(ap,AP);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer apellido materno
void LeerApellidoMaterno(char am[])
{
	int car, i=0, j, a[2];
	char AM[20],Esp[1], carA;
	bool ValA=false;
	do{
		i=0;
		system ("CLS");
		printf("Ingresa Apellido Materno:");
	
	do{
		car=getch();
		
		if(car==8 && i!=0){
			i=i-1;
			system ("CLS");
			printf("Ingresa Apellido Materno:");
			for(j=0;j<=i-1 ;j++){
				
				printf("%c",AM[j]);
			}
		}
		else{
			if(car >=97 && car <=122)
			{car = car-32;}
			if((car>=65 && car <=90 ) || car==32)
			{
				if(i==0 && car==' ')
				{
				}
				else
				{
					if(car==' ' && AM[i-1]==' ')
					{
					}
					else
					{
						printf("%c",car);
						AM[i]=car;
						i++;
					}
				}
			}
			if(car==164 || car == 165)
			{
				printf("%c",165);
				AM[i]=165;
				i++;
			}
		}
	}while(car!=ENTER);
	AM[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\nApellido materno: %s\n",AM);
	strcpy(am,AM);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer fecha
void LeerFecha(char Fc[])
{
	
	bool Val = true, ValA=false;
	int car, i=0, DobEsp, EspI, j, a[2];
	char D[3],M[3],Y[20],Esp[1],c2[20], carA;
	do{
		i=0;
		system ("CLS");
		printf("Ingresa Apellido Materno:");
	
	do{
		if(Val==false){i=0;}
		system("CLS");
		printf("Ingresa tu Fecha de nacimiento: __/__/____");
		if(Val==false){printf("\nFecha invalida ");}
	do{
		car=getch();
		
		if(car>=48 && car<=57 || car==8){
		if(car==8 && i!=0){
			i=i-1;
				if(i==0){
						system("CLS");
						printf("Ingresa tu Fecha de nacimiento: __/__/____");
					}
				if(i!=0 && i<=2)
					{
						system("CLS");
						if(i-1==0){printf("Ingresa tu Fecha de nacimiento: %c_/__/____",D[0]);}
						if(i-1==1){printf("Ingresa tu Fecha de nacimiento: %c%c/__/____",D[0],D[1]);}
						
					}
					if(i>=3 && i<=4)
					{
						system("CLS");
						if(i-1==2){printf("Ingresa tu Fecha de nacimiento: %c%c/%c_/____",D[0],D[1],M[0]);}
						if(i-1==3){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/____",D[0],D[1],M[0],M[1]);}
						
					}
					
					if(i>=5 && i<=9)
					{
						system("CLS");
						if(i-1==4){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c___",D[0],D[1],M[0],M[1],Y[0]);}
						if(i-1==5){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c__",D[0],D[1],M[0],M[1],Y[0],Y[1]);}
						if(i-1==6){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c_",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2]);}
						if(i-1==7){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c%c",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2],Y[3]);}
						
					}
					
		}
		else{
				if(i==0){
						system("CLS");
						printf("Ingresa tu Fecha de nacimiento: __/__/____");
					}
				if(car==' '){EspI=1;}
				else{EspI=0;}
				if(EspI==0 && car!=8)
				{
					if(i<=1)
					{
						system("CLS");
						D[i]=car;
						if(i==0){printf("Ingresa tu Fecha de nacimiento: %c_/__/____",D[0]);}
						if(i==1){printf("Ingresa tu Fecha de nacimiento: %c%c/__/____",D[0],D[1]);}
					}
					if(i>=2 && i<=3)
					{
						system("CLS");
						M[i-2]=car;
						if(i==2){printf("Ingresa tu Fecha de nacimiento: %c%c/%c_/____",D[0],D[1],M[0]);}
						if(i==3){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/____",D[0],D[1],M[0],M[1]);}
						
					}
					
					if(i>=4 && i<=8)
					{
						system("CLS");
						Y[i-4]=car;
						if(i==4){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c___",D[0],D[1],M[0],M[1],Y[0]);}
						if(i==5){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c__",D[0],D[1],M[0],M[1],Y[0],Y[1]);}
						if(i==6){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c_",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2]);}
						if(i==7){printf("Ingresa tu Fecha de nacimiento: %c%c/%c%c/%c%c%c%c",D[0],D[1],M[0],M[1],Y[0],Y[1],Y[2],Y[3]);}
						
					}
					c2[i]=car;
					i++;
				}
			}
	}

	}while( i!=8 );
	int Dia = (int) strtol(D, NULL, 10);
	int Mes = (int) strtol(M, NULL, 10);
	int Year = (int) strtol(Y, NULL, 10);
	if (Year>=1900 && Year<=2021){
		if(Mes==1 || Mes==3 || Mes==5 || Mes==7 || Mes==8 || Mes==10 || Mes==12){
			if(Dia>=1 && Dia<=31){Val=true;}
			else{Val=false;}
		}
		
		if(Mes==4 || Mes==6 || Mes==9 || Mes==11){
			if(Dia>=1 && Dia<=30){Val=true;}
			else{Val=false;}
		}
		
		if(Mes==2){
			if ( Year % 4 == 0 && Year % 100 != 0 || Year % 400 == 0){
			if(Dia>=1 && Dia<=29){Val=true;}
			else{Val=false;}
			}
			else{if(Dia>=1 && Dia<=28){Val=true;} else{Val=false;}}
		}
		if(Mes>12)
		{
			Val=false;
		}
		if(Dia>31)
		{
			Val=false;
		}
		
	}
	else{
		Val=false;
	}
	printf("\n%d/%d/%d\n",Dia,Mes,Year);
}while(Val!=true);
	
	c2[i]='\0';
	fflush(stdin);
	if(i>=20){printf("\nNumero maximo de caracteres alcanzado\n");}
	printf("\n%c%c/%c%c/%c%c%c%c\n",c2[0],c2[1],c2[2],c2[3],c2[4],c2[5],c2[6],c2[7]);
	strcpy(Fc,c2);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
		}while(ValA==false);
	}while(a[0]!='Y');
}


//**********************************************************************************
//Leer sexo
int LeerSexo()
{
    int car, i=0, DobEsp, EspI, j, Espp=0, a[2];
	char Sexo[5],Esp[1], carA;
	int ValA=false, ValB=true;
	//Sexo[0]=a;
	do{
		i=0;
		system ("CLS");
		printf("Selecciona tu Sexo:(Utilizando tabulador)  \n>Hombre		 Mujer");
	
	do{
		
		car=getch();
		
		
			if(car == TAB || i==0)
			{
			if(ValB==false)
			{
				system ("CLS");
				printf("Selecciona tu Sexo:(Utilizando tabulador)  \n Hombre		>Mujer");
				strcpy(Sexo, "Mujer");
				ValB=true;
			}
			
			else{
				system ("CLS");
				printf("Selecciona tu Sexo:(Utilizando tabulador) \n>Hombre		 Mujer");
				strcpy(Sexo, "Hombre");
				ValB=false;
			}
			
			}
			
		i++;
		
	}while(car!=ENTER);
	printf("\nSeleccionaste el genero: %s\n",Sexo);
	printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
			}while(ValA==false);
	}while(a[0]!='Y');
	
	return ValB;
}

//**********************************************************************************
//Leer E.F.
int LeerEntFed(char EntFed[])
{
	char sig[][33] = {"AS","BC","BS","CC","CL","CM","CS","CH","DF","DG","GT","GR","HG","JC","MC","MN","MS","NT","NL","OC","PL","QT","QR","SP","SL","SR","TC","TS","TL","VZ","YN","ZS","NE"},a[2],carA,car,cad[][33] = {"AGUASCALIENTES","BAJA CALIFORNIA","BAJA CALIFORNIA SUR","CAMPECHE","COAHUILA","COLIMA","CHIAPAS","CHIHUAHUA","DISTRITO FEDERAL","DURANGO","GUANAJUATO","GUERRERO","HIDALGO","JALISCO","MEXICO","MICHOACAN","MORELOS","NAYARIT","NUEVO LEON","OAXACA","PUEBLA","QUERETARO","QUINTANA ROO","SAN LUIS POTOSI","SINALOA","SONORA","TABASCO","TAMAULIPAS","TLAXCALA","VERACRUZ","YUCATAN","ZACATECAS","NACIDO EN EL EXTRANJERO"};
	int i,ValA=false;
	do
	{
		system("cls");
		printf("Selecciona tu estado de nacimiento: %s \n", cad[0]);
		printf("Utiliza las flechas de tu teclado para seleccionar el estado.\n");
		i=0;
		do
		{
			car = getch();
			//printf("%d",car);
			
			if (car == DERECHA || car == ABAJO)
			{
				if (i == 32)
				{
					i = -1;
				}
				i++;
			}
			else
			{
				if (car == ARRIBA || car == IZQUIERDA)
				{
					if (i == 0)
					{
						i = 33;
					}
					i--;
				}
			}
			system("cls");
			printf("Selecciona tu estado de nacimiento: %s \n", cad[i]);
			printf("Utiliza las flechas de tu teclado para seleccionar el estado.\n");
		} while (car != ENTER);
		
		printf("\nSeleccionaste esta entidad federativa: %s\n",cad[i]);
		printf("\nDesea confirmar los datos ingresados?(Y/N)\n");
			do{
			carA=getch();
			
			
			
				if(carA==121 || carA==110)
				{carA = carA-32;}
				if(carA==89 || carA==78 )
				{
							printf("%c",carA);
							a[0]=carA;
							ValA=true;
					
				}
				else{
					ValA=false;
				}
			}while(ValA==false);
	} while(a[0]!='Y');
	strcpy(EntFed,sig[i]);
}

