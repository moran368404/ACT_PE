//prueba para archivos

#include <stdio.h>
#include <conio.h>

int main()
{
	FILE *archi;
	char ch;
	
	archi = fopen("banner.txt","r");
	if (archi)
	{
		while(!feof(archi))
		{
			ch = fgetc(archi);
			fprintf(stdout,"%c",ch);
			
		}
		fclose(archi);
	}
	else
	{
		printf("ESE ARCHIVO NO EXISTE");
	}
}
