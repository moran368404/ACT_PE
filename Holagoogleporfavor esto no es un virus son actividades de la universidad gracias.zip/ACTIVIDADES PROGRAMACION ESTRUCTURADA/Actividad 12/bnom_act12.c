// BNOM_ACT12_01
// ACTIVIDAD 12
// BIANCA NOELIA OROZCO MORAN 368404
// 04 DE NOVIEMBRE DEL 2022

//****************************************************************
// LLAMADA A LIBRERIAS/DEFINE
#include "jorgito.h"

//****************************************************************
// DEFINICION DE LA ESTRUCTURA (molde)
typedef struct _alumnos{
	char status;
	long matricula;
	char nom[30];
	char AP[30];
	char AM[30];
	int edad;
	char sexo;
} Tsalumnos;

//****************************************************************
// DECLARACION DE FUNCIONES
int msges();

void menu_();
void impVect(Tsalumnos v[],int n);
void eli_busc(Tsalumnos v[],int n, int op);
void ordreg(Tsalumnos v[],int n);

Tsalumnos GenDatRand();
Tsalumnos GenDatMan();

//****************************************************************
// MAIN PRINCIPAL
int main()
{
	menu_();
	return 0;
}

//****************************************************************
// MENSAJES DEL MENU
int msges()
{
	int op;
	system("cls");
	printf(MAGENTA "*********************SISTEMA DE REGISTRO DE ALUMNOS*********************\n");
	printf("1.- AGREGAR (10 REGISTROS ALEATORIOS)\n");
	printf("2.- AGREGAR UN REGISTRO MANUALMENTE\n");
	printf("3.- ELIMINAR UN REGISTRO\n");
	printf("4.- BUSCAR\n");
	printf("5.- ORDENAR\n");
	printf("6.- IMPRIMIR\n");
	printf("0.- SALIR\n");
	printf("ESCOGE UNA OPCION: ");
	op = validNum(0,6,"ESCOGE UNA OPCION: ","ESA OPCION NO ESTA EN EL MENU");
	return op;
}

//****************************************************************
// DESARROLLO DEL MENU
void menu()
{
	int op,j,i=0,num;
	Tsalumnos vect[N],reg;
	do{
		op=msges();
		switch(op)
		{
			case 1:
				printf("\nAGREGAR REGISTROS");
				if(i<N-10)
				  {
						for(j=0;j<10;j++,i++)
						   {
						   		vect[i]=GenDatRand();
						   }
				  }
				printf("10 registros a%cadidos\n",164);
				system("pause");
				break;
			case 2:
				printf("\nAGREGAR MANUAL\n");
				printf("�Cuantos registros desea meter?\n");
				scanf("%d",&num);
				if(i<N-num)
				{
					for(j=0;j<num;j++,i++)
					{
						vect[i] = GenDatMan();
					}
				}
				system("pause");
				break;
			case 3:
				printf("\nELIMINAR REGISTROS");
				eli_busc(vect,i,op);
				system("pause");
				break;
			case 4:
				printf("\nBUSCAR REGISTROS");
				eli_busc(vect,i,op);
				system("pause");
				break;
			case 5:
				printf("\nORDENAR REGISTROS");
				ordreg(vect,i);
				system("pause");
				break;
			case 6:
				printf("\nIMPRIMIR REGISTROS");
				impVect(vect,i);
				system("pause");
				break;
			case 0:
				printf("\nSALIR");
				break;
		}
	} while (op!=0);
}

//****************************************************************
// GENERADOR DE DATOS ALEATORIO
Tsalumnos GenDatRand ()
{
	Tsalumnos reg;
	int sex;
	char nom[15][20];
	char nomMUJ[20][15] = {"Bianca","Noelia","Elisa","Ghizeth","Yaremi","Daniela","Luisa","Viviana","Alejandra","Karla","Doja","Snow","Maria","Alexa","Alicia"};
	char nomHOM[20][15]  = {"Jorge","Alejandro","Enrique","Luis","Miguel","Angel","Santiago","Sebastian","Jose","Misael","Isaac","Ali","Yael","Axel","Jesus","Pedro"};
	char APE[20][15] = {"Grimaldo","Hernandez","Tello","Mora","Villa","Juarez","Orozco","Moran","Nunez","Yepiz","Serna","Diaz","Yanez","Lizaola","Gali"};
	system("cls");
	// SEXO Y NOMBRE
	sex = rand()%2;
	
	if(sex == 0) 
	  {
	  		strcpy(reg.nom,nomMUJ[rand()%15]);
	  } 
	  else 
	  {
	  		strcpy(reg.nom,nomHOM[rand()%15]);
	  } // 0 = MUJER , 1 = HOMBRE
	  
	if (sex == 0)
	{
		reg.sexo = 'M';
	}
	else
	{
			reg.sexo = 'H';
	}
	
	// APELLIDOS
	strcpy(reg.AP,APE[rand()%15]);
	strcpy(reg.AM,APE[rand()%15]);
	
	// MATRICULA
	reg.matricula = rand()%70000 + 330000;
	
	// STATUS
	reg.status = 'A';
	
	// EDAD
	reg.edad = rand()%8 + 18;
	
	return reg;
}

//****************************************************************
// GENERADOR DE DATOS MANUAL
Tsalumnos GenDatMan()
{
	Tsalumnos regi;
	int sex,edad;
	long mat;
	char NOM[20], AP[20], AM[20],sexo;
	system("cls");
	fflush(stdin);
	validCad(regi.nom,"Dame tu nombre: ");
	fflush(stdin);
	validCad(regi.AP,"Dame tu apellido paterno: ");
	fflush(stdin);
	validCad(regi.AM,"Dame tu apellido materno: ");
	regi.status = 'A';
	regi.matricula = validLong(0, 100000000, "Dame tu matricula: ", "Esa matricula no es valida");
	regi.edad = validNum(0,100,"Dame tu edad: ","Esa edad no es valida");
	sex = validNum(0,1,"Dame tu sexo (0.- MUJER, 1.- HOMBRE): ","Esa no es una opcion");
	
	if (sex == 0)
	   {
			regi.sexo = 'M';
	   }
	else
	{
		if (sex == 1)
		   {
				regi.sexo = 'H';
		   }
		else
		{
			printf("Esa no es opcion.\n");
		}
	}
	
	return regi;
}
//****************************************************************
// IMPRIMIR VECTORES
void impVect(Tsalumnos v[],int n)
{
	int i;
	system("cls");
	printf("%8s\t%8s\t%8s\t%8s\t%8s\t%8s\t%8s\n","STATUS","MATRICULA","NOMBRE","AP PATERNO","AP MATERNO","EDAD","SEXO");
	for(i=0;i<n;i++)
	   {
	   		if (v[i].status == 'A')
	   		   {
	   		   		printf("%8c\t%8ld\t%8s\t%8s\t%8s\t%8d\t%8c\n",v[i].status,v[i].matricula,v[i].nom,v[i].AP,v[i].AM,v[i].edad,v[i].sexo);
			   }
	   }
}

//****************************************************************
// ELIMINAR/BUSCAR UN REGISTRO
void eli_busc(Tsalumnos v[],int n, int op)
{
	int i;
	long matri;
	
	system("cls");
	matri = validLong(300000,100000000,"�Que matricula buscas? ","Ese numero no es valido");
	for(i=0;(i<n )&&(v[i].matricula!=matri);i++)
	{
	}
	if (op == 3)
	{
		if(i==n)
		  {
		   		printf("Esa matricula no se encuentra en el sistema.\n");
	      }
	      else
	      {
				v[i].status = 'I';
				printf("\n Status: INACTIVO\n");
	      }
	}
	else
	{
		if(i>=n)
		  {
				printf("Esa matricula no se encuentra en el sistema.\n");
	      }
	      else
	      {
				printf("%8s\t%8s\t%8s\t%8s\t%8s\t%8s\t%8s\n","STATUS","MATRICULA","NOMBRE","AP PATERNO","AP MATERNO","EDAD","SEXO");
				printf("%8c\t%8ld\t%8s\t%8s\t%8s\t%8d\t%8c\n",v[i].status,v[i].matricula,v[i].nom,v[i].AP,v[i].AM,v[i].edad,v[i].sexo);
	      }
	}
	
	
}

//****************************************************************
// ORDENAR LAS MATRICULAS
void ordreg(Tsalumnos v[],int n)
{
	int i,j;
	long temp=0;
	Tsalumnos tempo;

	for (i=1;i<n;i++)
	{
     	  for (j=0; j < n-i ;j++) 
     	  {
     	     if (v[j].matricula > v[j+1].matricula)
     	     {
     	        tempo = v[j];
        	    v[j]=v[j+1];
            	v[j+1]=tempo;
    	      }
    	   }
	}
}


